"""Browser end-to-end test (Playwright + Chromium) against a live server.

    python3 tests/e2e_browser.py [screenshot_dir]

Starts the app on a random local port with a throwaway database, then drives a real browser through
the core editorial workflow. Uses synthetic data labelled FICTIONAL only. Exits non-zero on failure."""
import os
import sys
import tempfile
import threading

from PIL import Image
from playwright.sync_api import expect, sync_playwright
from werkzeug.serving import make_server

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from elf_archive import create_app, db as dbm  # noqa: E402
from tests.helpers import PASSWORD, make_user, publish_new  # noqa: E402

SHOTS = sys.argv[1] if len(sys.argv) > 1 else None


def main():
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "e2e.db")
    conn = dbm.connect(path)
    dbm.migrate(conn)
    contrib = make_user(conn, "e2e_contrib")
    editor = make_user(conn, "e2e_editor", ["editor"])
    make_user(conn, "e2e_mod", ["moderator"])
    place = publish_new(conn, contrib, editor, "place", {"primary_name": "Testville (FICTIONAL)", "aliases": "Testvil"})
    dup_keep = publish_new(conn, contrib, editor, "person", {"preferred_name": "Testperson Twin (FICTIONAL)", "living_status": "deceased",
                                                             "birth": "c. 2099", "birth_place": place["public_id"]})
    dup_retire = publish_new(conn, contrib, editor, "person", {"preferred_name": "Testperson Twin (FICTIONAL)", "living_status": "deceased",
                                                               "occupation": "Test occupation (fictional)"})
    conn.close()

    app = create_app({"ENV": "testing", "DATABASE_PATH": path, "SECRET_KEY": "e" * 40,
                      "MEDIA_ROOT": os.path.join(tmp, "media")})
    server = make_server("127.0.0.1", 0, app, threaded=True)
    base = f"http://127.0.0.1:{server.server_port}"
    threading.Thread(target=server.serve_forever, daemon=True).start()
    shot = (lambda page, name: page.screenshot(path=os.path.join(SHOTS, name), full_page=True)) if SHOTS else (lambda *a: None)
    steps = []

    with sync_playwright() as p:
        browser = p.chromium.launch()

        # 1. Contributor drafts, then submits a person record through the real form.
        ctx = browser.new_context(viewport={"width": 1280, "height": 900})
        page = ctx.new_page()
        page.goto(base + "/")
        shot(page, "01-home.png")
        page.get_by_role("link", name="Sign in", exact=True).click()
        page.fill("#f-identifier", "e2e_contrib")
        page.fill("#f-password", PASSWORD)
        page.click("button:has-text('Sign in')")
        expect(page.locator("h1")).to_contain_text("Welcome")
        page.get_by_role("link", name="New record: Person", exact=True).click()
        page.fill("#f-preferred_name", "Testperson Browser (FICTIONAL)")
        page.fill("#f-aliases", "Testperson Brauser")
        page.fill("#f-birth", "c. 2099")
        page.fill("#f-birth_place", "Testville (FICTIONAL)")
        page.fill("#f-summary", "Synthetic person created by the browser test.")
        page.fill("#f-sources", "Test Register (FICTIONAL) | p. 9 | https://example.test/register")
        page.fill("#f-birth", "1952-02-30")                       # invalid on purpose: server must reject it
        page.click("button:has-text('Save draft')")
        expect(page.locator("#error-summary")).to_be_visible()
        expect(page.locator("#e-birth")).to_contain_text("does not exist")
        shot(page, "02-form-error.png")
        page.fill("#f-birth", "c. 2099")
        page.click("button:has-text('Save and submit for review')")
        expect(page.locator(".notice--ok")).to_contain_text("Submitted for editorial review")
        shot(page, "03-submitted.png")
        steps.append("contributor: invalid date rejected, draft saved and submitted")

        # 2. Not public yet.
        anon = browser.new_context().new_page()
        anon.goto(base + "/search?q=browser")
        expect(anon.locator("main")).to_contain_text("No published records match")
        steps.append("visitor: unpublished submission not searchable")

        # 3. Editor reviews, asks for changes.
        ectx = browser.new_context(viewport={"width": 1280, "height": 900})
        ed = ectx.new_page()
        ed.goto(base + "/auth/login")
        ed.fill("#f-identifier", "e2e_editor")
        ed.fill("#f-password", PASSWORD)
        ed.click("button:has-text('Sign in')")
        ed.goto(base + "/editor")
        shot(ed, "04-queue.png")
        ed.get_by_role("link", name="Testperson Browser (FICTIONAL)").click()
        ed.click("button:has-text('Start review')")
        ed.fill("#m-nr", "Please add an occupation if known (test).")
        ed.click("button:has-text('Return for revision')")
        expect(ed.locator(".notice--ok")).to_contain_text("Returned to the contributor")
        steps.append("editor: started review and returned it for revision")

        # 4. Contributor sees the request, revises, resubmits.
        page.goto(base + "/dashboard/submissions")
        page.get_by_role("link", name="Testperson Browser (FICTIONAL)").click()
        expect(page.locator("main")).to_contain_text("Please add an occupation")
        page.get_by_role("link", name="Edit", exact=True).click()
        expect(page.locator("#f-birth")).to_have_value("c. 2099")        # uncertainty survives the round trip
        page.fill("#f-occupation", "Test occupation (fictional)")
        page.click("button:has-text('Save and submit for review')")
        expect(page.locator(".notice--ok")).to_contain_text("Submitted")
        steps.append("contributor: saw the editor's message, revised and resubmitted")

        # 5. Editor approves and publishes.
        ed.reload()
        ed.click("button:has-text('Start review')")
        ed.click("button:has-text('Approve')")
        ed.on("dialog", lambda d: d.accept())
        shot(ed, "05-review-approved.png")
        ed.click("button:has-text('Publish')")
        expect(ed.locator(".notice--ok")).to_contain_text("Published")
        steps.append("editor: approved and published")

        # 6. Public: searchable by alias, profile shows uncertainty + citation, linked from the place page.
        anon.goto(base + "/search?q=brauser")
        anon.get_by_role("link", name="Testperson Browser (FICTIONAL)").click()
        expect(anon.locator("h1")).to_have_text("Testperson Browser (FICTIONAL)")
        expect(anon.locator("main")).to_contain_text("c. 2099")
        expect(anon.locator("main")).to_contain_text("Test Register (FICTIONAL)")
        expect(anon.locator(".notice--fictional")).to_have_count(0)       # real-flow record is not flagged as seed data
        shot(anon, "06-person.png")
        anon.get_by_role("link", name="Testville (FICTIONAL)").click()
        expect(anon.locator("main")).to_contain_text("Testperson Browser (FICTIONAL)")
        steps.append("visitor: found by alias, profile shows approximate date and citation, linked from place page")

        # 7. Mobile: compact menu works and nothing scrolls sideways.
        m = browser.new_context(viewport={"width": 375, "height": 740}, is_mobile=True, has_touch=True).new_page()
        m.goto(base + "/people")
        expect(m.locator("#nav-toggle")).to_be_visible()
        expect(m.locator("#nav-wrap")).to_be_hidden()
        m.click("#nav-toggle")
        expect(m.locator("#nav-wrap")).to_be_visible()
        expect(m.locator("#nav-toggle")).to_have_attribute("aria-expanded", "true")
        overflow = m.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 0, f"horizontal overflow of {overflow}px on mobile"
        shot(m, "07-mobile-menu.png")
        m.goto(base + "/map")
        expect(m.locator("main")).to_contain_text("Places without documented coordinates")
        steps.append("mobile: menu toggles, no horizontal overflow, map list alternative reachable")

        # 8. Keyboard: first Tab reaches the skip link and it moves focus to main.
        k = browser.new_context().new_page()
        k.goto(base + "/")
        k.keyboard.press("Tab")
        expect(k.locator(".skip")).to_be_focused()
        k.keyboard.press("Enter")
        assert k.evaluate("document.activeElement.id") == "main"
        steps.append("keyboard: skip link works")

        # 9. Languages: the switcher changes the interface; Arabic is right-to-left and fits a phone screen.
        lc = browser.new_context(viewport={"width": 1280, "height": 900})
        lp = lc.new_page()
        lp.goto(base + "/people")
        lp.get_by_role("link", name="العربية").click()
        expect(lp.locator("html")).to_have_attribute("dir", "rtl")
        expect(lp.locator("html")).to_have_attribute("lang", "ar")
        assert lp.url.endswith("/people"), lp.url                       # stayed on the same page
        expect(lp.locator("h1")).to_have_text("الأشخاص")
        expect(lp.locator(".lang-note")).to_be_visible()                 # draft-translation notice
        shot(lp, "09-arabic-people.png")
        lp.goto(base + "/")
        shot(lp, "09-arabic-home.png")
        lp.get_by_role("link", name="ትግርኛ").click()
        expect(lp.locator("html")).to_have_attribute("dir", "ltr")
        expect(lp.locator("#nav-wrap")).to_contain_text("ሰባት")
        shot(lp, "09-tigrinya-home.png")
        lm = browser.new_context(viewport={"width": 375, "height": 740}, is_mobile=True, has_touch=True).new_page()
        lm.goto(base + "/language/ar?next=/")
        lm.click("#nav-toggle")
        expect(lm.locator("#nav-wrap")).to_be_visible()
        overflow = lm.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 0, f"horizontal overflow of {overflow}px on mobile (Arabic)"
        shot(lm, "09-arabic-mobile.png")
        lp.get_by_role("link", name="English").click()
        expect(lp.locator("html")).to_have_attribute("lang", "en")
        steps.append("languages: switch to Arabic (RTL) and Tigrinya and back, no overflow on mobile in Arabic")

        # 10. Photos: contributor uploads through the real form (with progress), editor approves, visitors see it.
        img_path = os.path.join(tmp, "upload-test.jpg")
        Image.new("RGB", (1200, 800), (150, 110, 70)).save(img_path, "JPEG")
        page.goto(base + "/contribute/person")
        page.fill("#f-preferred_name", "Testperson Photo Browser (FICTIONAL)")
        page.click("button:has-text('Save draft')")
        expect(page.locator(".notice--ok")).to_contain_text("Draft saved")
        page.set_input_files("#f-photo", img_path)
        page.fill("#f-caption", "Synthetic colour block for the browser test (FICTIONAL)")
        page.select_option("#f-rights_status", "copyrighted_permission_granted")
        page.fill("#f-rights_holder", "Test Holder (FICTIONAL)")
        page.check("#f-rights_declared")
        page.click("button:has-text('Upload')")
        expect(page.locator(".notice--ok")).to_contain_text("Photo added")
        thumb = page.locator(".photo-list img").first
        expect(thumb).to_be_visible()
        assert thumb.evaluate("i => i.naturalWidth") > 0
        shot(page, "10-photo-uploaded.png")
        page.click("button:has-text('Submit for review')")
        expect(page.locator(".notice--ok")).to_contain_text("Submitted")
        ed.goto(base + "/editor")
        ed.get_by_role("link", name="Testperson Photo Browser (FICTIONAL)").click()
        expect(ed.locator("main")).to_contain_text("Photo decisions needed")
        ed.click("button:has-text('Start review')")
        ed.select_option("select[name=access]", "public")
        ed.select_option("select[name=rights_status]", "copyrighted_permission_granted")
        ed.click("button:has-text('Save photo decision')")
        expect(ed.locator(".notice--ok")).to_contain_text("Photo decision saved")
        shot(ed, "10-photo-review.png")
        ed.click("button:has-text('Approve')")
        ed.click("button:has-text('Publish')")
        expect(ed.locator(".notice--ok")).to_contain_text("Published")
        anon.goto(base + "/archive")
        anon.locator(".gallery a").first.click()
        img = anon.locator("figure.photo img")
        expect(img).to_be_visible()
        assert img.evaluate("i => i.naturalWidth") > 0
        expect(anon.locator("main")).to_contain_text("Testperson Photo Browser (FICTIONAL)")
        shot(anon, "10-archive-item.png")
        steps.append("photos: uploaded with progress, decided and published by an editor, visible to visitors")

        # 11. Map: the self-hosted basemap of Eritrea draws (no tile service), and the list alternative is there.
        mp = browser.new_context(viewport={"width": 1280, "height": 900}).new_page()
        external = []
        mp.on("request", lambda r: external.append(r.url) if not r.url.startswith(base) and not r.url.startswith("data:") else None)
        mp.goto(base + "/map")
        expect(mp.locator(".leaflet-container")).to_be_visible()
        expect(mp.locator("path.land--eritrea").first).to_be_attached()      # (the strict CSP forbids eval-based waits)
        expect(mp.locator("main")).to_contain_text("Places without documented coordinates")
        assert not external, f"map made requests to other sites: {external[:3]}"
        shot(mp, "11-map.png")
        steps.append("map: basemap drawn from the archive's own server, no third-party requests")

        # 12. Forum: a member posts, another replies and reports it, a moderator removes it with a reason.
        page.goto(base + "/community/c/hometowns/new")
        page.fill("#tt", "Browser test topic (FICTIONAL)")
        page.fill("#tb", "A synthetic forum post written by the browser test (FICTIONAL).")
        page.click("button:has-text('Post topic')")
        expect(page.locator("h1")).to_have_text("Browser test topic (FICTIONAL)")
        topic_url = page.url
        ed.goto(topic_url)
        ed.fill("#rb", "A synthetic reply (FICTIONAL).")
        ed.click("button:has-text('Post reply')")
        expect(ed.locator("main")).to_contain_text("A synthetic reply (FICTIONAL).")
        ed.locator("details.inline-details summary", has_text="Report").first.click()
        ed.locator("button:has-text('Send report')").first.click()
        expect(ed.locator(".notice--ok")).to_contain_text("A moderator will look at your report")
        mod = browser.new_context(viewport={"width": 1280, "height": 900}).new_page()
        mod.goto(base + "/auth/login")
        mod.fill("#f-identifier", "e2e_mod")
        mod.fill("#f-password", PASSWORD)
        mod.click("button:has-text('Sign in')")
        mod.goto(base + "/moderation")
        expect(mod.locator("main")).to_contain_text("Browser test topic (FICTIONAL)")
        shot(mod, "12-moderation-queue.png")
        mod.goto(topic_url)
        mod.locator("details.inline-details summary", has_text="Moderate").first.click()
        first_post = mod.locator("form[action^='/moderation/posts/']").first
        first_post.locator("select[name=action]").select_option("remove")
        first_post.locator("input[name=reason]").fill("Browser test of moderation (FICTIONAL)")
        first_post.locator("button:has-text('Apply')").click()
        expect(mod.locator(".notice--ok")).to_contain_text("moderation log")
        anon.goto(topic_url)
        expect(anon.locator("main")).to_contain_text("This post was removed by a moderator.")
        expect(anon.locator("main")).not_to_contain_text("written by the browser test")
        steps.append("forum: posted, replied, reported, removed by a moderator with a logged reason")

        # 13. Merge: an editor merges a duplicate; the retired record's address redirects to the kept one.
        ed.goto(base + f"/editor/merge?keep={dup_keep['public_id']}&retire={dup_retire['public_id']}")
        expect(ed.locator("main")).to_contain_text("Testperson Twin (FICTIONAL)")
        ed.fill("#mr", "Same person: identical test records created by the browser test (FICTIONAL).")
        ed.click("button:has-text('Merge')")
        expect(ed.locator(".notice--ok")).to_contain_text("now redirects")
        anon.goto(base + f"/people/{dup_retire['slug']}")
        assert anon.url.endswith(f"/people/{dup_keep['slug']}"), anon.url
        steps.append("merge: duplicate merged with a reason; old address redirects")

        # 14. Accessibility: axe-core (WCAG 2.0–2.2 A/AA rules) on the main pages, public and signed in, English and Arabic.
        axe = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor", "axe.min.js"), encoding="utf-8").read()
        person_slug = dup_keep["slug"]
        public_pages = ["/", "/people", f"/people/{person_slug}", f"/places/{place['slug']}", "/map", "/timeline", "/families",
                        "/archive", "/oral-histories", "/community", topic_url.replace(base, ""), "/search?q=test", "/about",
                        "/standards", "/contact", "/auth/login", "/auth/register", "/accessibility"]
        problems = []

        def scan(pg, url):
            pg.goto(base + url)
            pg.add_script_tag(content=axe)
            res = pg.evaluate("""() => axe.run(document, {runOnly: {type: 'tag', values: ['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}})
                                  .then(r => r.violations.map(v => ({id: v.id, impact: v.impact, n: v.nodes.length,
                                                                    target: v.nodes[0].target.join(' '), help: v.help})))""")
            for v in res:
                problems.append(f"{url} [{v['impact']}] {v['id']}: {v['help']} ({v['n']}x, e.g. {v['target']})")

        actx = browser.new_context(viewport={"width": 1280, "height": 900}, bypass_csp=True)   # CSP bypass only to inject axe
        ap = actx.new_page()
        for u in public_pages:
            scan(ap, u)
        ap.goto(base + "/language/ar?next=/")
        for u in ("/", "/people", f"/people/{person_slug}", "/contact"):
            scan(ap, u)
        ap.goto(base + "/language/en?next=/")
        ap.goto(base + "/auth/login")
        ap.fill("#f-identifier", "e2e_editor")
        ap.fill("#f-password", PASSWORD)
        ap.click("button:has-text('Sign in')")
        for u in ("/dashboard", "/dashboard/profile", "/dashboard/security", "/contribute/person", "/editor", "/editor/duplicates"):
            scan(ap, u)
        dark = browser.new_context(viewport={"width": 1280, "height": 900}, bypass_csp=True, color_scheme="dark").new_page()
        dark_pages = ("/", "/people", f"/people/{person_slug}", "/map", topic_url.replace(base, ""), "/archive", "/auth/login")
        for u in dark_pages:
            scan(dark, u)
        n_pages = len(public_pages) + 4 + 6 + len(dark_pages)
        if problems:
            print("\n".join(problems))
            raise AssertionError(f"{len(problems)} accessibility violation(s) found by axe-core")
        steps.append(f"accessibility: axe-core found no WCAG A/AA violations on {n_pages} pages (English, Arabic, signed in, dark mode)")

        browser.close()
    server.shutdown()
    for s in steps:
        print("PASS", s)
    print(f"{len(steps)} browser scenarios passed")


if __name__ == "__main__":
    main()
