// Interactive map of Eritrea. Progressive enhancement: without JavaScript the page lists every place.
// The base map is the archive's own (Natural Earth, public domain) served from this server; there is
// no third-party tile service unless an administrator configures one. Places come from /map/data.json,
// the same public records used everywhere else. Text from records is inserted with textContent only.
(function () {
  'use strict';
  function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  ready(function () {
    var el = document.getElementById('map');
    if (!el || !window.L || !window.fetch) return;
    var T = JSON.parse(el.getAttribute('data-i18n'));
    var highlight = JSON.parse(el.getAttribute('data-highlight') || '[]');
    var personFilter = JSON.parse(el.getAttribute('data-person') || '""');
    var tile = JSON.parse(el.getAttribute('data-tile') || '""');
    var tileAttribution = JSON.parse(el.getAttribute('data-tile-attribution') || '""');
    var status = document.getElementById('map-status');
    var form = document.getElementById('map-filters');
    var say = function (text) { status.textContent = text; };
    var fmt = function (s, vals) { return s.replace(/\{(\w+)\}/g, function (_, k) { return vals[k]; }); };

    el.innerHTML = '';
    el.classList.add('map--live');
    say(T.loading);

    var eritrea = L.latLngBounds([12.3, 36.4], [18.05, 43.15]);
    var map = L.map(el, { zoomSnap: 0.25, minZoom: 5, maxZoom: tile ? 17 : 11, maxBounds: L.latLngBounds([9.5, 31.5], [21.5, 47.5]), maxBoundsViscosity: 0.8,
                          keyboard: true, worldCopyJump: false, attributionControl: true });
    map.fitBounds(eritrea);
    map.attributionControl.setPrefix(false);
    map.attributionControl.addAttribution(T.attribution);
    ['base', 'labels', 'places'].forEach(function (name, i) { map.createPane(name).style.zIndex = String(350 + i * 100); });

    var overlays = {};
    if (tile) {
      overlays[T.street] = L.tileLayer(tile, { attribution: tileAttribution, maxZoom: 17 });
    }

    // ---- base map ----
    fetch('/map/basemap.json').then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }).then(function (b) {
      L.geoJSON(b.countries, { pane: 'base', interactive: false,
        style: function (f) { return { className: f.properties.code === 'ERI' ? 'land land--eritrea' : 'land' }; } }).addTo(map);
      var regions = L.geoJSON(b.regions, { pane: 'base', interactive: false, style: function () { return { className: 'region-line' }; } });
      var regionLabels = L.layerGroup();
      b.regions.features.forEach(function (f) {
        var c = L.geoJSON(f).getBounds().getCenter();
        regionLabels.addLayer(L.marker(c, { pane: 'labels', interactive: false, keyboard: false,
          icon: L.divIcon({ className: 'region-label', html: '', iconSize: null }) }).on('add', function (e) {
            e.target.getElement().textContent = f.properties.name; }));
      });
      var rivers = L.geoJSON(b.rivers, { pane: 'base', interactive: false, style: function () { return { className: 'river' }; } });
      var towns = L.layerGroup();
      b.towns.features.forEach(function (f) {
        if (!f.properties.eri && f.properties.rank > 3) return;
        var ll = [f.geometry.coordinates[1], f.geometry.coordinates[0]];
        towns.addLayer(L.circleMarker(ll, { pane: 'labels', radius: 2.5, className: 'town-dot', interactive: false })
          .bindTooltip(f.properties.name, { permanent: true, direction: 'right', className: 'town-label', offset: [4, 0] }));
      });
      var regionGroup = L.layerGroup([regions, regionLabels]).addTo(map);
      rivers.addTo(map);
      towns.addTo(map);
      overlays[T.regions] = regionGroup;
      overlays[T.rivers] = rivers;
      overlays[T.towns] = towns;
      L.control.layers(null, overlays, { collapsed: window.innerWidth < 700 }).addTo(map);
    }).catch(function () { /* the archive markers still work without the base layers */ });

    // ---- archive places ----
    var all = [], cluster = L.markerClusterGroup({ showCoverageOnHover: false, maxClusterRadius: 36, clusterPane: 'places' });
    map.addLayer(cluster);

    function norm(s) {
      return (s || '').normalize('NFKD').replace(/[̀-ًͯ-ٟ]/g, '').replace(/['’‘ʼʻʿʾ`´]/g, '')
        .toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
    }

    function popup(p) {
      var box = document.createElement('div'); box.className = 'map-popup';
      var h = document.createElement('a'); h.href = p.url; h.textContent = p.name; h.className = 'map-popup__title'; h.dir = 'auto';
      box.appendChild(h);
      var meta = document.createElement('div'); meta.className = 'small muted';
      meta.textContent = [p.type_label, p.region].filter(Boolean).join(' · ');
      box.appendChild(meta);
      if (p.fictional) { var fb = document.createElement('div'); fb.className = 'badge badge--fictional'; fb.textContent = T.fictional; box.appendChild(fb); }
      if (p.precision !== 'exact') {
        var n = document.createElement('p'); n.className = 'small map-popup__warn';
        n.textContent = p.precision === 'region_centroid' ? T.centroid : T.approx;
        if (p.note) { n.appendChild(document.createElement('br')); n.appendChild(document.createTextNode(p.note)); }
        box.appendChild(n);
      }
      if (p.events.length) {
        var eh = document.createElement('div'); eh.className = 'small map-popup__h'; eh.textContent = T.events; box.appendChild(eh);
        var ul = document.createElement('ul'); ul.className = 'plain-list small';
        p.events.slice(0, 5).forEach(function (ev) {
          var li = document.createElement('li'), a = document.createElement('a');
          a.href = ev.url; a.textContent = ev.title; a.dir = 'auto';
          li.appendChild(a); li.appendChild(document.createTextNode(' · ' + ev.date)); ul.appendChild(li);
        });
        box.appendChild(ul);
        if (p.events.length > 5) {
          var more = document.createElement('a'); more.className = 'small'; more.href = '/timeline?place=' + encodeURIComponent(p.id);
          more.textContent = fmt(T.more, { n: p.events.length - 5 }); box.appendChild(more);
        }
      }
      if (p.people) { var pp = document.createElement('div'); pp.className = 'small'; pp.textContent = fmt(T.people, { n: p.people }); box.appendChild(pp); }
      var links = document.createElement('p'); links.className = 'small';
      var open = document.createElement('a'); open.href = p.url; open.textContent = T.open; links.appendChild(open);
      if (p.events.length) {
        links.appendChild(document.createTextNode(' · '));
        var tl = document.createElement('a'); tl.href = '/timeline?place=' + encodeURIComponent(p.id); tl.textContent = T.timeline; links.appendChild(tl);
      }
      box.appendChild(links);
      return box;
    }

    function marker(p) {
      var icon = L.divIcon({ className: 'pin pin--' + p.precision + (p.fictional ? ' pin--fictional' : ''), html: '<span></span>',
                             iconSize: [22, 22], iconAnchor: [11, 11], popupAnchor: [0, -10] });
      var m = L.marker([p.lat, p.lon], { icon: icon, title: p.name, alt: p.name, keyboard: true, pane: 'places', riseOnHover: true });
      m.bindPopup(function () { return popup(p); }, { maxWidth: 300 });
      return m;
    }

    function matches(p, f) {
      if (highlight.length && highlight.indexOf(p.id) < 0) return false;
      if (personFilter && !highlight.length) return false;
      if (f.q && (norm(p.name) + ' ' + p.names).indexOf(norm(f.q)) < 0) return false;
      if (f.ptype && p.type !== f.ptype) return false;
      var evs = p.events;
      if (f.type) evs = evs.filter(function (e) { return e.type === f.type; });
      if (f.from || f.to) evs = evs.filter(function (e) {
        return e.from !== null && (!f.from || e.to >= f.from) && (!f.to || e.from <= f.to); });
      if ((f.type || f.from || f.to) && !evs.length) return false;
      return true;
    }

    function current() {
      var d = new FormData(form);
      return { q: (d.get('q') || '').trim(), ptype: d.get('ptype') || '', type: d.get('type') || '',
               from: parseInt(d.get('from'), 10) || null, to: parseInt(d.get('to'), 10) || null };
    }

    var shown = [];
    function apply(fit) {
      var f = current();
      cluster.clearLayers();
      shown = all.filter(function (x) { return matches(x.p, f); });
      cluster.addLayers(shown.map(function (x) { return x.m; }));
      say(shown.length ? fmt(T.shown, { n: shown.length, total: all.length }) : T.none);
      if (fit && shown.length) map.fitBounds(L.latLngBounds(shown.map(function (x) { return x.m.getLatLng(); })).pad(0.3), { maxZoom: 9 });
    }

    fetch('/map/data.json').then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }).then(function (data) {
      all = data.places.map(function (p) { return { p: p, m: marker(p) }; });
      apply(highlight.length > 0);
    }).catch(function () { say(T.error); });

    var timer;
    form.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(function () { apply(false); }, 150); });
    form.addEventListener('change', function () { apply(false); });
    form.addEventListener('reset', function () { setTimeout(function () { apply(false); }, 0); });
    form.addEventListener('submit', function (e) { e.preventDefault(); apply(true); });
    document.getElementById('map-fit').addEventListener('click', function () {
      if (shown.length) map.fitBounds(L.latLngBounds(shown.map(function (x) { return x.m.getLatLng(); })).pad(0.3), { maxZoom: 9 });
      else map.fitBounds(eritrea);
    });
  });
})();
