"""Map, timeline filters, family tree and connections explorer. Every view must lead only to real,
public records and never reveal a restricted person. Test places use coordinates in the open sea
(0.5, 0.5), which are obviously not Eritrean geography; all records are labelled fictional."""
import json
import unittest

from elf_archive import create_app, queries, security
from elf_archive.services import graph
from tests.helpers import make_db, make_user, publish, publish_new, submit_new
from tests.test_http import Client


class Base(unittest.TestCase):
    def setUp(self):
        self.db = make_db()
        self.app = create_app({"ENV": "testing", "DATABASE_PATH": ":memory:", "_SHARED_CONNECTION": self.db,
                               "SECRET_KEY": "x" * 40, "BASE_URL": "http://archive.test"})
        self.contrib = make_user(self.db, "contrib")
        self.editor = make_user(self.db, "editor1", ["editor"])
        self.c = Client(self.app)

    def new(self, kind, **raw):
        return publish_new(self.db, self.contrib, self.editor, kind, raw)

    def link(self, kind, **raw):
        return publish(self.db, self.editor, submit_new(self.db, self.contrib, kind, raw))

    def rel(self, a, b, t="parent_of", **kw):
        sid = submit_new(self.db, self.editor, "relationship", {"person_a": a["public_id"], "person_b": b["public_id"],
                                                               "relationship_type": t, **kw})
        editor2 = self.db.execute("SELECT id FROM users WHERE username='editor2'").fetchone()
        from tests.helpers import cu
        return publish(self.db, cu(self.db, editor2[0]) if editor2 else make_user(self.db, "editor2", ["editor"]), sid)


class MapAndTimeline(Base):
    def setUp(self):
        super().setUp()
        self.exact = self.new("place", primary_name="Testport (FICTIONAL)", latitude="0.5", longitude="0.5",
                              coord_precision="exact", place_type="town_city", aliases="Testporto")
        self.approx = self.new("place", primary_name="Testhill (FICTIONAL)", latitude="0.6", longitude="0.4",
                               coord_precision="approximate", coord_note="Location estimated from a test memoir (FICTIONAL)")
        self.nowhere = self.new("place", primary_name="Testvale (FICTIONAL)")
        self.ev1 = self.new("event", title="Test Battle Drill (FICTIONAL)", date="2098 to 2099", event_type="battle_conflict",
                            place=self.exact["public_id"])
        self.ev2 = self.new("event", title="Test Meeting (FICTIONAL)", date="c. 2097", event_type="meeting_conference",
                            place=self.approx["public_id"])
        self.ev3 = self.new("event", title="Test Undated Gathering (FICTIONAL)", place=self.exact["public_id"])
        self.person = self.new("person", preferred_name="Testperson Mapped (FICTIONAL)", birth_place=self.approx["public_id"])
        self.org = self.new("organization", name="Test Front (FICTIONAL)")
        self.link("participation", event=self.ev1["public_id"], person=self.person["public_id"])
        self.link("participation", event=self.ev2["public_id"], organization=self.org["public_id"])
        self.living = publish_new(self.db, self.contrib, self.editor, "person",
                                  {"preferred_name": "Testperson Living Map (FICTIONAL)", "living_status": "living",
                                   "birth_place": self.exact["public_id"]})

    def test_map_data_uses_only_documented_public_places(self):
        data = self.c.get("/map/data.json").get_json()["places"]
        by_name = {p["name"]: p for p in data}
        self.assertEqual(set(by_name), {"Testport (FICTIONAL)", "Testhill (FICTIONAL)"})     # no coordinates → not mapped
        port, hill = by_name["Testport (FICTIONAL)"], by_name["Testhill (FICTIONAL)"]
        self.assertEqual((port["precision"], hill["precision"]), ("exact", "approximate"))
        self.assertIn("estimated", hill["note"])
        self.assertIn("testporto", port["names"])
        self.assertEqual({e["title"] for e in port["events"]}, {"Test Battle Drill (FICTIONAL)", "Test Undated Gathering (FICTIONAL)"})
        drill = next(e for e in port["events"] if e["title"].startswith("Test Battle"))
        self.assertEqual((drill["from"], drill["to"], drill["type"]), (2098, 2099, "battle_conflict"))
        undated = next(e for e in port["events"] if "Undated" in e["title"])
        self.assertIsNone(undated["from"])                   # never given a false year
        self.assertEqual(port["people"], 0)                  # the living person is not counted
        self.assertEqual(hill["people"], 1)
        self.assertNotIn("Living Map", json.dumps(data))

    def test_basemap_is_served_from_this_server(self):
        r = self.c.get("/map/basemap.json")
        base = json.loads(r.get_data(as_text=True))
        self.assertEqual(len(base["regions"]["features"]), 6)
        self.assertIn("Natural Earth", base["source"])
        self.assertIn("No historical boundaries", base["note"])
        html = self.c.get("/map").get_data(as_text=True)
        self.assertIn("/static/vendor/leaflet/leaflet.js", html)
        self.assertIn("Testvale (FICTIONAL)", html)          # listed, not placed

    def test_person_filter_shows_their_documented_places(self):
        ids = queries.person_place_ids(self.db, self.person["public_id"])
        self.assertEqual(set(ids), {self.exact["public_id"], self.approx["public_id"]})
        html = self.c.get(f"/map?person={self.person['public_id']}").get_data(as_text=True)
        self.assertIn("Testperson Mapped (FICTIONAL)", html)
        self.assertIsNone(queries.person_place_ids(self.db, self.living["public_id"]))

    def test_timeline_filters(self):
        def titles(qs):
            html = self.c.get("/timeline?" + qs).get_data(as_text=True)
            return {t for t in ("Test Battle Drill", "Test Meeting", "Test Undated Gathering") if t in html}
        self.assertEqual(titles(""), {"Test Battle Drill", "Test Meeting", "Test Undated Gathering"})
        self.assertEqual(titles("type=battle_conflict"), {"Test Battle Drill"})
        self.assertEqual(titles(f"place={self.exact['public_id']}"), {"Test Battle Drill", "Test Undated Gathering"})
        self.assertEqual(titles(f"person={self.person['public_id']}"), {"Test Battle Drill"})
        self.assertEqual(titles(f"organization=Test Front (FICTIONAL)"), {"Test Meeting"})
        self.assertEqual(titles("from=2099"), {"Test Battle Drill"})               # range 2098–2099 overlaps 2099
        self.assertEqual(titles("to=2097"), {"Test Meeting"})                      # undated events are never in a period
        self.assertEqual(titles("q=meeting"), {"Test Meeting"})
        self.assertEqual(titles(f"person={self.living['public_id']}"), set())       # private record: matches nothing
        html = self.c.get("/timeline?type=battle_conflict").get_data(as_text=True)
        self.assertIn("/map?type=battle_conflict", html)
        self.assertIn('name="robots" content="noindex"', html)

    def test_csp_allows_a_configured_tile_host_only(self):
        self.assertNotIn("tile", security.build_csp({}))
        csp = security.build_csp({"MAP_TILE_URL": "https://tile.openstreetmap.org/{z}/{x}/{y}.png"})
        self.assertIn("img-src 'self' data: https://tile.openstreetmap.org", csp)
        self.assertEqual(security.build_csp({"MAP_TILE_URL": "http://insecure.test/{z}"}), security.CSP)


class TreesAndConnections(Base):
    def setUp(self):
        super().setUp()
        p = lambda n, **kw: self.new("person", preferred_name=f"Testperson {n} (FICTIONAL)", **kw)  # noqa: E731
        self.gp, self.parent, self.spouse, self.child, self.adopted = p("Grand"), p("Parent", birth="c. 2060"), p("Spouse"), p("Child"), p("Adopted")
        self.secret = publish_new(self.db, self.contrib, self.editor, "person",
                                  {"preferred_name": "Testperson Secret (FICTIONAL)", "living_status": "living"})
        self.rel(self.gp, self.parent)
        self.rel(self.parent, self.spouse, "spouse_of")
        self.rel(self.parent, self.child)
        self.rel(self.spouse, self.child)
        self.rel(self.parent, self.adopted, "adoptive_parent_of", status="disputed")
        # a restricted (living) child, recorded by staff: the workflow itself refuses links to non-public people
        self.db.execute("INSERT INTO relationships(person_a_id, person_b_id, relationship_type, publication_status, visibility) "
                        "VALUES (?,?, 'parent_of', 'published', 'restricted')", (self.parent["id"], self.secret["id"]))

    def test_tree_has_generations_and_hides_restricted_people(self):
        t = graph.person_tree(self.db, self.parent["id"])
        gens = [[n["name"] for n in row] for row in t["generations"]]
        self.assertEqual(len(gens), 3)
        self.assertIn("Testperson Grand (FICTIONAL)", gens[0])
        self.assertEqual(set(gens[1]), {"Testperson Parent (FICTIONAL)", "Testperson Spouse (FICTIONAL)"})
        self.assertEqual(set(gens[2]), {"Testperson Child (FICTIONAL)", "Testperson Adopted (FICTIONAL)"})
        self.assertNotIn("Secret", json.dumps([n["name"] for n in t["nodes"]]))
        html = self.c.get(f"/people/{self.parent['slug']}/tree").get_data(as_text=True)
        for n in (self.gp, self.child, self.adopted):
            self.assertIn(f'href="/people/{n["slug"]}"', html)
        self.assertIn("edge--adoptive_parent_of edge--disputed", html)
        self.assertIn("Disputed", html)
        self.assertNotIn("Secret", html)
        self.assertIn("<svg", html)

    def test_family_tree_marks_members(self):
        fam = self.new("family", display_name="Testfamily Tree (FICTIONAL)")
        for who in (self.parent, self.child):
            self.db.execute("INSERT INTO family_memberships(family_id, person_id, publication_status, visibility) VALUES (?,?, 'published','public')",
                            (fam["id"], who["id"]))
        html = self.c.get(f"/families/{fam['slug']}/tree").get_data(as_text=True)
        self.assertEqual(html.count("tree-node--member"), 2)
        self.assertIn("Testperson Spouse (FICTIONAL)", html)                  # one step beyond the members
        empty = self.new("family", display_name="Testfamily Empty (FICTIONAL)")
        self.assertIn("No family tree can be drawn yet", self.c.get(f"/families/{empty['slug']}/tree").get_data(as_text=True))

    def test_connections_explain_every_link_and_never_infer_acquaintance(self):
        org = self.new("organization", name="Test Union (FICTIONAL)")
        colleague = self.new("person", preferred_name="Testperson Colleague (FICTIONAL)")
        for who in (self.parent, colleague):
            self.link("affiliation", person=who["public_id"], organization=org["public_id"])
        self.db.execute("INSERT INTO affiliations(person_id, organization_id, publication_status, visibility) VALUES (?,?, 'published', 'public')",
                        (self.secret["id"], org["id"]))      # even a wrongly public link to a restricted person must not leak
        html = self.c.get(f"/people/{self.parent['slug']}/connections").get_data(as_text=True)
        self.assertIn("Testperson Colleague (FICTIONAL)", html)
        self.assertIn("This does not mean they knew each other.", html)
        self.assertIn(f"/organizations/{org['slug']}", html)
        self.assertIn("Spouse of", html)
        self.assertNotIn("Secret", html)
        self.assertEqual(self.c.get(f"/people/{self.secret['slug']}/connections").status_code, 404)


if __name__ == "__main__":
    unittest.main()
