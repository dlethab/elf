# ELF Digital Historical Archive

A connected, searchable historical archive for the Eritrean Liberation Front and Eritrea's independence struggle. People, families, places, events, organizations and sources are shared records linked to each other, with claim-level citations and honest handling of uncertainty. It also includes an editorial review workflow, photographs, documents, recordings and consent-based oral histories, an interactive map of Eritrea, family trees and connection diagrams, a moderated community forum, and an interface in English, Tigrinya and Arabic.

## Documentation

| Document | For |
| --- | --- |
| `docs/STATUS.md` | What works, what was tested, what remains |
| `docs/LAUNCH_CHECKLIST.md` | Steps before going live |
| `docs/DEPLOYMENT.md` | Putting it on a Linux server with HTTPS, services, email and backups |
| `docs/ADMIN_GUIDE.md` | Running the archive day to day (administrators, editors, moderators) |
| `docs/EDITORIAL.md` | Editorial guidelines: evidence, living people, rights, consent |
| `docs/OPERATIONS.md` | Backup, restore, export, upgrades, troubleshooting |
| `docs/PERMISSIONS.md` | Roles and what each can do |
| `docs/ARCHITECTURE.md` | Design, data model, routes, testing |
| `docs/SPECIFICATION.md` | The original product specification |

## Requirements

- Python 3.12 or newer (SQLite with FTS5 is included with standard Python builds)
- Nothing else for development: no database server, no Node toolchain. `ffmpeg` is optional (strips metadata from audio and video).

## Development setup

**Windows (PowerShell)**, from the project folder:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\flask.exe --app elf_archive migrate
.\.venv\Scripts\flask.exe --app elf_archive create-admin --email you@example.org --username you   # prompts for a password
.\.venv\Scripts\flask.exe --app elf_archive run --debug
```

**macOS / Linux:**

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
flask --app elf_archive migrate
flask --app elf_archive create-admin --email you@example.org --username you
flask --app elf_archive run --debug
```

Open http://localhost:5000. Mail you trigger (verification, password reset) is queued in the database; in development read it at http://localhost:5000/dev/outbox. Copying `.env.example` to `.env` is optional in development.

### Trying it with fictional data (development only)

```bash
flask --app elf_archive seed-test-data
```

This adds records named "… (FICTIONAL)", flagged in the database and labelled on every page: people, a family, a place, events, organizations, affiliations, an oral history with a transcript, and forum topics. It also creates dev accounts (`dev_admin`, `dev_editor`, `dev_editor2`, `dev_moderator`, `dev_contrib`, `dev_rep`, `dev_researcher`) with a printed random password. Fictional records carry no coordinates and use the year 2099 so they cannot be mistaken for history. Running it again on a database seeded by an older version adds only the newer sections. The command refuses to run in production. Delete `instance/archive.db` to start over.

## Tests

```bash
python -m unittest discover -s tests -t .       # unit, service and HTTP integration tests
python tests/e2e_browser.py [screenshot_dir]    # 14 real-browser scenarios incl. an axe-core accessibility scan
                                                # (first: python -m playwright install chromium)
python -m tests.i18n_keys ar                    # lists interface text missing from a translation
pip-audit -r requirements.txt                   # known vulnerabilities in dependencies
```

## Operator commands

`flask --app elf_archive <command>` (on a server, the `elf` wrapper from `docs/DEPLOYMENT.md`):

| Command | Purpose |
| --- | --- |
| `migrate` | Apply pending database migrations (safe to re-run) |
| `create-admin --email … --username …` | Create an administrator; the password is prompted, never passed on the command line |
| `send-email` | Deliver queued email via SMTP (needs `ELF_SMTP_*`) |
| `backup DEST.db [--media DIR]` | Online database copy with integrity check, plus an incremental copy of media files |
| `export-public DEST.zip` | Public data export (JSON + CSV, public fields only) |
| `reindex` | Rebuild the public search index |
| `seed-test-data` | Development only: fictional records and dev accounts |

## Project layout

```
elf_archive/
  vocab.py            controlled vocabularies (single source for DB CHECK constraints and code)
  permissions.py      the permission matrix; every server-side check uses it
  migrations/         numbered SQL migrations
  db.py               connections, transactions, migration runner
  services/           business logic: accounts, entities, records, workflow, search, curation, merging,
                      importer, photos/media, oral histories, collections, graph, forum, mfa, export
  queries.py          read-side queries for public pages (always filtered to public records)
  security.py         CSRF, headers, cache policy, route guards
  i18n.py             interface languages; catalogues in translations/
  web/                Flask blueprints: public, auth, dashboard, editor, admin, community
  templates/          Jinja templates; _macros.html holds the shared components
  static/             CSS, progressive-enhancement JS, vendored Leaflet, the Eritrea base map
tools/build_basemap.py  rebuilds static/map/eritrea-basemap.json from Natural Earth
tests/                unit, HTTP integration and browser end-to-end tests
docs/                 see the table above
```

## Third-party components

Flask, Werkzeug and Jinja (BSD-3), Pillow (MIT-CMU), qrcode (BSD), Leaflet (BSD-2) and Leaflet.markercluster (MIT) vendored in `static/vendor`, map data from Natural Earth (public domain). Tests only: Playwright (Apache-2.0), axe-core (MPL-2.0) in `tests/vendor`.
