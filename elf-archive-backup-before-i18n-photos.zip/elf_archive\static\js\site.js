// Progressive enhancement only. Every page works without JavaScript.
document.documentElement.classList.add('js');
document.addEventListener('DOMContentLoaded', function () {
  // Compact navigation toggle on small screens.
  var btn = document.getElementById('nav-toggle'), wrap = document.getElementById('nav-wrap');
  if (btn && wrap) {
    btn.addEventListener('click', function () {
      var open = wrap.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  // Warn before leaving a contribution form with unsaved changes.
  document.querySelectorAll('form[data-warn-unsaved]').forEach(function (form) {
    var dirty = false;
    form.addEventListener('input', function () { dirty = true; });
    form.addEventListener('submit', function () { dirty = false; });
    window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  });
  // Ask for confirmation on irreversible editorial actions.
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) { if (!window.confirm(el.getAttribute('data-confirm'))) e.preventDefault(); });
  });
  // Move focus to the error summary when a form comes back with errors.
  var summary = document.getElementById('error-summary');
  if (summary) summary.focus();
});
