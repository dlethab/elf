"""ELF Digital Historical Archive — application factory."""
from pathlib import Path
from urllib.parse import urlencode

from flask import Flask, g, render_template, request, session

from . import db as dbm
from . import queries, security
from .config import load_config
from .services import accounts, dates
from .vocab import EVIDENCE, KIND_LABELS, STATUS_LABELS


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.update(load_config(overrides))
    app.config.update(
        SESSION_COOKIE_NAME="elf_session", SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=app.config["ENV"] == "production",
        PERMANENT_SESSION_LIFETIME=app.config["SESSION_LIFETIME_SECONDS"],
    )
    path = app.config["DATABASE_PATH"]
    if path != ":memory:":
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    if app.config["AUTO_MIGRATE"] and not app.config.get("_SHARED_CONNECTION"):
        conn = dbm.connect(path)
        dbm.migrate(conn)
        conn.close()
    app.teardown_appcontext(dbm.close_db)

    @app.before_request
    def _load_user_and_csrf():
        g.user = None
        if request.endpoint == "static":
            return None
        raw = session.get("sid")
        if raw:
            g.user = accounts.load_session(dbm.get_db(), raw)
            if g.user is None:
                session.pop("sid", None)
        security.check_csrf()

    app.after_request(security.apply_headers)

    # Stateless helpers are Jinja globals so imported macros can use them too.
    app.jinja_env.globals.update(
        csrf_token=security.csrf_token, fdate=dates.format_date, precision_note=dates.precision_note,
        record_url=queries.record_url, status_label=lambda s: STATUS_LABELS.get(s, (s, "•")),
        kind_label=lambda k: KIND_LABELS.get(k, k), EVIDENCE=EVIDENCE, page_url=_page_url,
        site_name=app.config["SITE_NAME"], contact_email=app.config["CONTACT_EMAIL"],
        base_url=app.config["BASE_URL"], is_dev=app.config["ENV"] in ("development", "testing"),
    )

    @app.context_processor
    def _inject():
        unread = 0
        if g.get("user"):
            unread = dbm.get_db().execute("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL",
                                          (g.user.id,)).fetchone()[0]
        return {"current_user": g.get("user"), "can": lambda perm: bool(g.get("user") and g.user.can(perm)),
                "unread_notifications": unread}

    from .web import admin, auth, dashboard, editor, public
    for bp in (public.bp, auth.bp, dashboard.bp, editor.bp, admin.bp):
        app.register_blueprint(bp)
    if app.config["ENV"] in ("development", "testing"):
        app.register_blueprint(auth.dev_bp)   # never registered in production

    from . import cli
    cli.register(app)

    def _err(code, title, text):
        def handler(e):
            desc = getattr(e, "description", None) if code == 400 else None
            return render_template("errors/error.html", code=code, title=title, text=desc or text), code
        return handler

    app.register_error_handler(400, _err(400, "Request could not be processed", "Please go back and try again."))
    app.register_error_handler(403, _err(403, "Not permitted", "You do not have permission to do this."))
    app.register_error_handler(404, _err(404, "Not found", "This page does not exist or is not publicly available."))
    app.register_error_handler(405, _err(405, "Method not allowed", "That action is not available here."))
    app.register_error_handler(413, _err(413, "Too large", "The submitted content is too large."))
    app.register_error_handler(429, _err(429, "Too many requests", "Please wait a little and try again."))

    @app.errorhandler(500)
    def _500(e):
        app.logger.exception("Unhandled error")      # details go to the server log only
        return render_template("errors/error.html", code=500, title="Something went wrong",
                               text="The error has been logged. Please try again later."), 500

    return app


def _page_url(n):
    args = request.args.to_dict()
    args["page"] = n
    return f"{request.path}?{urlencode(args)}"
