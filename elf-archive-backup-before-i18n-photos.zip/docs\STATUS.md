# Status — end of Milestone 1

## What works (built and tested)

- **Accounts:** registration with honeypot and rate limit, email verification, sign-in with lockout after 5 failures, sign-out that revokes the session server-side, password reset with no account enumeration, password change that signs out other sessions, profile with attribution preference, notifications.
- **Roles and permissions:** contributor (implicit), editor, moderator, administrator, plus scoped and revocable family-representative grants. Enforced on the server; see `PERMISSIONS.md`.
- **Shared record model:** people, families, places, events and sources as canonical entities with permanent IDs, stable URLs, slug-change redirects, names and aliases in any script, uncertain dates, claim-level citations, append-only revision history and audit log. Schema for organizations, affiliations, archive items, media, collections, oral histories, consent and the forum is in place.
- **Editorial workflow:** draft → submit → review → return for revision → resubmit → approve → publish, plus reject and withdraw. Corrections show a side-by-side diff and are additive for names and sources. Duplicate-name hints for editors (and, limited to public records, for contributors). Living people publish as restricted unless consent is confirmed. Editors cannot review their own work. Publication is atomic.
- **Public site:** home page with real counts only, list pages with A–Z filter and pagination, person, family, place, event and source pages with related records, citations and public change history, global search across names, aliases, transliterations and historical place names, timeline by decade with undated events listed separately, map list alternative, information and policy pages, contact form, sitemap and robots.
- **Editorial and admin tools:** queue with flags (living person, no sources, possible duplicate, record changed since submission, rights note), review page, internal notes, staff record view with access changes (reason required), slug changes, family-representative management, contact messages, user and role management, deactivation and anonymisation, audit log, configurable place and event categories, operational overview.
- **Design system:** tokens, components, dark mode, reduced motion, strict CSP, works without JavaScript, responsive down to 375 px.
- **Operations:** migrations, create-admin, backup with integrity check, reindex, email delivery, dev-only fictional seed.

## What was tested

| Check | Result |
| --- | --- |
| `python3 -m unittest discover -s tests -t .` | 59 tests pass (33 service, 26 HTTP) |
| `python3 tests/e2e_browser.py` (Chromium) | 8 scenarios pass |
| Spec §26.3 scenarios covered | 1, 2, 3, 4, 5, 6, 7, 8, 9, 13, 14, 15 (list alternative), 16 |
| Spec §26.3 scenarios not yet coverable | 10 (restricted files; no uploads yet), 11 (merging; Milestone 2), 12 (forum; Milestone 5) |
| Backup then restore from the copy | Manual run: integrity ok, pages and search served from the restored file |
| Screenshots reviewed | Home, form error, queue, review, person page, mobile menu |

**Not run:** no linter or type checker is installed in this environment (no network to install one), so none was run. No automated accessibility scanner (axe) is available offline; accessibility was checked by markup review, keyboard and mobile browser tests only. No load testing.

## What remains

- **Milestone 2:** merging duplicates (UI and service; the tombstone and redirect path already exists), editor tools to add citations and rate their evidence, record conflicting accounts, manage organizations and affiliations, link family members and event participants through the workflow, CSV import with preview.
- **Milestone 3:** interactive map, timeline filters, family tree and network explorer.
- **Milestone 4:** uploads, media storage and access control, rights, collections, oral histories with consent.
- **Milestone 5:** forum and moderation.
- **Milestone 6:** exports, Tigrinya and Arabic interfaces with right-to-left layout, multifactor authentication, independent accessibility and security review, deployment guide for the chosen host.
- Policy pages (privacy, terms, copyright, data licence) are drafts describing what the software does; they need adoption by the archive and legal review.

## Decisions that need your input

1. **Hosting and database.** The build uses SQLite because PostgreSQL could not be installed or tested here. It suits a single server with a persistent disk. If you plan to host on a platform without persistent disk, or expect very high simultaneous contribution volume, say so and I will plan the PostgreSQL migration (see `ARCHITECTURE.md` §2).
2. **Map tiles (needed for Milestone 3).** Options: OpenStreetMap's public tiles (free, but their usage policy does not allow heavy production use), a commercial provider such as MapTiler or Stadia Maps (needs an account and API key), or self-hosted tiles (no third party, more setup). Tell me which you prefer.
3. **Media storage (needed for Milestone 4).** Local disk on the server, or an S3-compatible service (Backblaze B2, Cloudflare R2, AWS S3, etc.). The latter needs an account and keys.

## External services and credentials

| Service | Needed for | Status |
| --- | --- | --- |
| A server with Python 3.12+, persistent disk and TLS | Running the site | Not configured |
| SMTP email provider | Verification and reset emails reaching users | Optional now; mail is queued until configured |
| Map tile provider (and key, if commercial) | Interactive map | Decision needed (Milestone 3) |
| S3-compatible object storage | Media files | Decision needed (Milestone 4) |
| Off-site backup storage under a separate account | Continuity | Not configured |
| Malware scanning (e.g. ClamAV on the server) | Uploads | Milestone 4 |
