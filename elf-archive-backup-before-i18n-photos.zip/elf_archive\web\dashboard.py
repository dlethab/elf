"""Contributor dashboard and contribution forms. Every route checks ownership on the server;
a submission that is not yours returns 404 (it is never confirmed to exist)."""
import json

from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, session, url_for

from ..db import get_db, tx
from ..security import login_required
from ..services import accounts, duplicates, entities, families, records, workflow
from ..services.workflow import PermissionDenied, WorkflowError
from ..vocab import KIND_LABELS

bp = Blueprint("dashboard", __name__)

NEW_KINDS = ("person", "family", "place", "event", "source")


def _cfg(drafting=False):
    cfg = dict(current_app.config)
    if drafting:                       # drafts may be saved before email verification; submitting may not
        cfg["REQUIRE_EMAIL_VERIFICATION"] = False
    return cfg


def _choices(db, kind):
    return {f.name: records.choices_for(db, f) for f in records.spec_for(kind) if records.choices_for(db, f) is not None}


def _own(sid):
    s = get_db().execute("SELECT * FROM submissions WHERE id=?", (sid,)).fetchone()
    if not s or s["submitter_id"] != g.user.id:
        abort(404)
    return s


def _form_kind(s):
    if s["kind"] == "correction":
        return entities.get(get_db(), s["target_entity_id"])["kind"]
    return s["kind"]


# ───────────── overview ─────────────
@bp.route("/dashboard")
@login_required
def home():
    db = get_db()
    counts = {r["status"]: r["n"] for r in db.execute(
        "SELECT status, COUNT(*) AS n FROM submissions WHERE submitter_id=? GROUP BY status", (g.user.id,))}
    recent = workflow.user_submissions(db, g.user.id)[:8]
    return render_template("dashboard/home.html", counts=counts, recent=[(s, workflow.title_for(db, s)) for s in recent],
                           fams=families.families_for_user(db, g.user.id), new_kinds=NEW_KINDS, kind_labels=KIND_LABELS,
                           notes=db.execute("SELECT * FROM notifications WHERE user_id=? AND read_at IS NULL ORDER BY id DESC LIMIT 5",
                                            (g.user.id,)).fetchall())


@bp.route("/dashboard/submissions")
@login_required
def submissions():
    db = get_db()
    status = request.args.get("status") or None
    rows = workflow.user_submissions(db, g.user.id, status)
    return render_template("dashboard/submissions.html", rows=[(s, workflow.title_for(db, s)) for s in rows], status=status)


@bp.route("/dashboard/submissions/<int:sid>")
@login_required
def submission(sid):
    db = get_db()
    s = _own(sid)
    data = json.loads(s["proposed_data"])
    ctx = {"s": s, "title": workflow.title_for(db, s), "events": workflow.visible_events(db, g.user, sid),
           "published": entities.get(db, s["result_entity_id"]) if s["result_entity_id"] else None}
    if s["kind"] == "correction":
        ctx["diff"] = records.diff(db, _form_kind(s), s["target_entity_id"], data["changes"])
        ctx["target"] = entities.get(db, s["target_entity_id"])
    else:
        ctx["rows"] = records.display_rows(db, s["kind"], data)
    if s["kind"] == "person" and s["status"] in workflow.EDITABLE + ("submitted",):
        cands = duplicates.find_person_candidates(db, [data.get("preferred_name"), data.get("full_name")] + data.get("aliases", []))
        ctx["possible_existing"] = [c for c in cands if entities.get_public_by_public_id(db, c["public_id"], "person")]
    return render_template("dashboard/submission.html", **ctx)


# ───────────── create / edit ─────────────
def _save(kind, form_kind, *, sid=None, target=None, family=None):
    """Validate the posted form; create or update the draft; optionally submit. Returns (response | None, errors)."""
    db = get_db()
    clean, errors = records.validate(db, form_kind, request.form)
    if not errors and target is not None:
        changes = records.changed_fields(db, form_kind, target["id"], clean)
        if not changes:
            errors["form"] = "You have not changed anything yet. Edit the fields that are wrong, or add a source."
        data = {"changes": changes}
    else:
        data = clean
    note, rights = request.form.get("contributor_note"), request.form.get("rights_note")
    if errors:
        return None, errors
    try:
        if sid is None:
            with tx(db):
                sid = workflow.create(db, g.user, kind, data, target=target, family=family,
                                      contributor_note=note, rights_note=rights, config=_cfg())
        else:
            workflow.update_draft(db, g.user, sid, data, contributor_note=note, rights_note=rights)
        if request.form.get("action") == "submit":
            workflow.transition(db, g.user, sid, "submitted", config=_cfg())
            flash("Submitted for editorial review. You will be notified when an editor responds.", "ok")
        else:
            flash("Draft saved. It is visible only to you until you submit it.", "ok")
    except PermissionDenied as e:
        flash(f"Your draft was saved, but it could not be submitted: {e}", "error")
    except WorkflowError as e:
        if sid is None:
            return None, {"form": str(e)}
        flash(str(e), "error")
    return redirect(url_for("dashboard.submission", sid=sid)), {}


def _form(kind, form_kind, values, errors, *, heading, target=None, family=None, s=None, status=200):
    db = get_db()
    return render_template("dashboard/contribute.html", fields=records.spec_for(form_kind), values=values, errors=errors,
                           choices=_choices(db, form_kind), kind=kind, form_kind=form_kind, heading=heading,
                           target=target, family=family, s=s, kind_label=KIND_LABELS[form_kind],
                           contributor_note=(request.form.get("contributor_note") if request.method == "POST" else (s["contributor_note"] if s else "")) or "",
                           rights_note=(request.form.get("rights_note") if request.method == "POST" else (s["rights_note"] if s else "")) or ""), status


@bp.route("/contribute/<any(person,family,place,event,source):kind>", methods=["GET", "POST"])
@login_required
def contribute(kind):
    db = get_db()
    try:
        workflow.authorize_new(db, g.user, kind, config=_cfg(drafting=True))
    except PermissionDenied:
        abort(403)
    if request.method == "POST":
        resp, errors = _save(kind, kind)
        if resp:
            return resp
        return _form(kind, kind, request.form, errors, heading=f"New {KIND_LABELS[kind].lower()} record", status=400)
    return _form(kind, kind, {}, {}, heading=f"New {KIND_LABELS[kind].lower()} record")


@bp.route("/contribute/correction/<public_id>", methods=["GET", "POST"])
@login_required
def correction(public_id):
    db = get_db()
    try:
        target, _ = workflow.authorize_new(db, g.user, "correction", target_public_id=public_id, config=_cfg(drafting=True))
    except WorkflowError:
        abort(404)
    except PermissionDenied:
        abort(403)
    fk = target["kind"]
    title = entities.title_of(db, target["id"])
    if request.method == "POST":
        resp, errors = _save("correction", fk, target=target)
        if resp:
            return resp
        return _form("correction", fk, request.form, errors, heading=f"Suggest a correction: {title}", target=target, status=400)
    return _form("correction", fk, records.form_values(records.current_clean(db, fk, target["id"]), fk), {},
                 heading=f"Suggest a correction: {title}", target=target)


@bp.route("/contribute/relationship", methods=["GET", "POST"])
@login_required
def relationship():
    db = get_db()
    fam_pid = request.values.get("family") or None
    try:
        _, family = workflow.authorize_new(db, g.user, "relationship", family_public_id=fam_pid, config=_cfg(drafting=True))
    except PermissionDenied:
        abort(403)
    heading = "Propose a family relationship" + (f": {entities.title_of(db, family['id'])}" if family else "")
    if request.method == "POST":
        resp, errors = _save("relationship", "relationship", family=family)
        if resp:
            return resp
        return _form("relationship", "relationship", request.form, errors, heading=heading, family=family, status=400)
    return _form("relationship", "relationship", {}, {}, heading=heading, family=family)


@bp.route("/dashboard/submissions/<int:sid>/edit", methods=["GET", "POST"])
@login_required
def edit(sid):
    db = get_db()
    s = _own(sid)
    if s["status"] not in workflow.EDITABLE:
        flash("This submission can no longer be edited.", "error")
        return redirect(url_for("dashboard.submission", sid=sid))
    fk = _form_kind(s)
    target = entities.get(db, s["target_entity_id"]) if s["kind"] == "correction" else None
    family = entities.get(db, s["family_scope_id"]) if s["family_scope_id"] else None
    heading = f"Edit: {workflow.title_for(db, s)}"
    if request.method == "POST":
        resp, errors = _save(s["kind"], fk, sid=sid, target=target, family=family)
        if resp:
            return resp
        return _form(s["kind"], fk, request.form, errors, heading=heading, target=target, family=family, s=s, status=400)
    data = json.loads(s["proposed_data"])
    if target is not None:
        base = records.current_clean(db, fk, target["id"])
        base.update(data["changes"])
        data = base
    return _form(s["kind"], fk, records.form_values(data, fk), {}, heading=heading, target=target, family=family, s=s)


@bp.route("/dashboard/submissions/<int:sid>/<any(submit,withdraw):action>", methods=["POST"])
@login_required
def act(sid, action):
    db = get_db()
    _own(sid)
    try:
        workflow.transition(db, g.user, sid, "submitted" if action == "submit" else "withdrawn", config=_cfg())
        flash("Submitted for editorial review." if action == "submit" else "Submission withdrawn.", "ok")
    except (PermissionDenied, WorkflowError) as e:
        flash(str(e), "error")
    return redirect(url_for("dashboard.submission", sid=sid))


# ───────────── account ─────────────
@bp.route("/dashboard/profile", methods=["GET", "POST"])
@login_required
def profile():
    db = get_db()
    errors = {}
    if request.method == "POST":
        try:
            with tx(db):
                accounts.update_profile(db, g.user.id, request.form)
            flash("Profile saved.", "ok")
            return redirect(url_for("dashboard.profile"))
        except accounts.AccountError as e:
            errors = e.errors
    u = db.execute("SELECT username, email, display_name, bio, languages, research_interests, attribution_pref, "
                   "notify_submission_updates, email_verified_at FROM users WHERE id=?", (g.user.id,)).fetchone()
    return render_template("dashboard/profile.html", u=u, errors=errors), (400 if errors else 200)


@bp.route("/dashboard/password", methods=["GET", "POST"])
@login_required
def password():
    db = get_db()
    errors = {}
    if request.method == "POST":
        if request.form.get("new_password") != request.form.get("new_password2"):
            errors["new_password2"] = "The passwords do not match."
        else:
            try:
                with tx(db):
                    accounts.change_password(db, g.user.id, request.form.get("current_password"),
                                             request.form.get("new_password"), keep_session_raw=session.get("sid"))
                flash("Password changed. Your other sessions have been signed out.", "ok")
                return redirect(url_for("dashboard.home"))
            except accounts.AccountError as e:
                errors = e.errors
    return render_template("dashboard/password.html", errors=errors), (400 if errors else 200)


@bp.route("/dashboard/notifications", methods=["GET", "POST"])
@login_required
def notifications():
    db = get_db()
    if request.method == "POST":
        from ..services.timeutil import now_iso
        db.execute("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL", (now_iso(), g.user.id))
        return redirect(url_for("dashboard.notifications"))
    rows = db.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100", (g.user.id,)).fetchall()
    return render_template("dashboard/notifications.html", rows=rows)
