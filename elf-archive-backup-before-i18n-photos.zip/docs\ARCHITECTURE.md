# Architecture

This document is the architecture proposal requested by the specification (§28 Rule 2, §30 A–D). It describes what is built, the reasoning, and the tradeoffs.

## 1. Environment findings

The project started from an empty workspace (no repository). The build environment has Python 3.13 with Flask 3.1, Werkzeug, Jinja2 and Pillow, SQLite 3.45 with FTS5, Node 22, ffmpeg, ImageMagick and Playwright with Chromium. It has **no PostgreSQL** and **no general internet access**, so packages beyond those installed cannot be fetched and a Next.js/Prisma/PostgreSQL stack could not be installed, run or tested here.

## 2. Stack and the main tradeoff

| Concern | Choice | Why |
| --- | --- | --- |
| Web framework | Flask 3 (Python), server-rendered Jinja templates | Available and testable here; small, stable, easy for a small team to maintain; server rendering gives crawlable pages and works without JavaScript |
| Database | SQLite (WAL mode), plain SQL migrations | One file, trivial to back up and move (spec §22.5), full-text search built in, no server to operate |
| Search | SQLite FTS5 with a public-only index | Built in; diacritic-insensitive tokenizer; enough for an archive of this size |
| Auth | Werkzeug scrypt password hashing + server-side session table | Maintained primitives, not custom crypto; sessions are revocable server-side |
| Styling | One hand-written CSS design system with tokens | No build step; strict CSP (no inline styles or scripts) |
| Tests | `unittest` + Flask test client + Playwright | All available offline |

**Tradeoff — the spec's default was Next.js + PostgreSQL.** The Flask + SQLite stack was chosen because it is the one that could actually be built, run and tested in this environment, and because a historical archive has few concurrent writers (editors and contributors), which suits SQLite well. Costs: SQLite allows one writer at a time (fine for this workload; not for thousands of simultaneous contributors), and hosting must give the app a persistent disk. **Migration path:** the schema is standard SQL with foreign keys and CHECK constraints; moving to PostgreSQL would mean translating the macros in `db.py`, replacing FTS5 with `tsvector`, and rewriting the append-only triggers in PL/pgSQL. The service layer would not change. This is the one decision flagged for the project owner in `STATUS.md`.

## 3. Project structure and layering

```
web/ (HTTP: parse request, call service, render)  →  services/ (rules, validation, transactions)  →  SQLite
queries.py (read-only public queries, always PUBLIC_WHERE)
permissions.py (role → permission matrix)   security.py (CSRF, headers, cache, route guards)
```

Templates never query the database. Historical content is data only; nothing historical is hard-coded in templates (spec Rule 6).

## 4. Data model

The full schema is in `elf_archive/migrations/`. Key design points:

### 4.1 Shared entity registry
Every canonical record (person, family, place, event, organization, source, archive item, collection, oral history) has one row in **`entities`** holding: permanent ID (`per-xxxxxxxx`), slug, publication status, visibility, merge pointer, soft-delete time, fictional-test flag. Each kind has a subtype table (`people`, `places`, …) keyed by the same id.

**Referential integrity for polymorphic links (spec §19.2):** every subtype table and every link column carries a fixed `kind` column, and foreign keys reference `entities(id, kind)`. A `birth_place_id` therefore *cannot* point at a person, and a citation's `source_id` cannot point at an event. This is enforced by SQLite, not by application code, and is tested.

### 4.2 Core tables

| Area | Tables |
| --- | --- |
| Identity | `users`, `user_roles`, `user_sessions` (hashed tokens), `auth_tokens` (hashed), `rate_events`, `outbox` |
| Registry | `entities`, `entity_slug_history` (old URLs redirect), `entity_names` (names, aliases, transliterations, original script; `normalized` search form kept separately) |
| People and families | `people`, `families`, `family_memberships`, `family_representatives` (scoped, revocable grants), `relationships` |
| Organizations | `organizations`, `affiliations` (time-ranged, evidence-rated) |
| Places and events | `places` (+ coordinate precision), `place_alt_locations`, `place_types`, `events`, `event_types`, `event_places`, `event_participants` |
| Evidence | `sources`, `citations` (one source → one claim on one record), `conflicting_accounts` |
| History | `revisions` (full snapshots, append-only), `audit_logs` (append-only), `merges` |
| Workflow | `submissions`, `submission_events` (append-only), `notifications`, `contact_messages` |
| Archive (schema only) | `archive_items`, `media_files` (checksums, derivatives, access level), `collections`, `collection_items`, `oral_histories`, `consent_records` (one row per consent type) |
| Community (schema only) | `forum_categories`, `forum_topics`, `forum_posts`, `reports`, `moderation_actions` (append-only) |

### 4.3 Uncertain dates (spec §19.3)
Each date is four columns: `*_start`, `*_end`, `*_precision` (exact, month, year, decade, approximate, range, unknown), `*_note`. Start and end hold partial ISO strings (`1952`, `1952-03`, `1952-03-14`); nothing is padded to a fake day. A CHECK constraint forbids a stored date when precision is `unknown`. Conflicting dates are recorded in `conflicting_accounts`.

### 4.4 Relationships
`relationships` holds typed person-to-person links (parent, adoptive parent, step-parent, guardian, spouse, partner, sibling, other documented) with status (current, historical, uncertain, disputed), dates, notes, publication and visibility. Symmetric types are stored once in canonical order (CHECK constraint), so A–B and B–A cannot both exist. Nothing assumes relationships are biological.

### 4.5 Integrity rules enforced by the database
Composite kind foreign keys; no half coordinates; coordinates require a precision; no date with "unknown" precision; append-only revisions, audit log, submission events and moderation log (triggers); one active family-representative grant per user and family; one active consent row per type; derivatives must point at their original file.

### 4.6 Deletion and retention
Historical records are never hard-deleted by the application: they are archived, restricted, merged (tombstone with `merged_into`) or soft-deleted. User accounts are deactivated and then anonymised (personal fields replaced) so contribution and audit history survives without personal data.

## 5. Visibility rule

One definition, `PUBLIC_WHERE` in `services/entities.py`: published **and** public **and** not deleted **and** not merged. Every public query, the search index, the sitemap, and record resolution use it. A restricted or draft record returns the same 404 as a record that never existed, and appears in no list, search result, related-record panel, relationship list, sitemap or metadata. People recorded as living are published as **restricted** unless an editor explicitly confirms consent.

## 6. Editorial workflow

```
draft ─▶ submitted ─▶ under_review ─▶ approved ─▶ published
  │          │  ▲          │              │
  │          ▼  │          ▼              ▼
  │    needs_revision ◀────┘          rejected
  └──▶ withdrawn (by submitter, any time before approval)
```

`services/workflow.py` is the only code path that creates or changes public records from contributions. It checks the transition is legal, the actor's permission, that editors are not reviewing their own work (configurable), that a reason is given for returns and rejections, and that referenced places and people are still public at publication time. Publication runs in a single transaction: either the record, its names, sources, citations, revision, audit entry and search index entry are all written, or none are.

Contributions never touch entity tables until published. Corrections store only the changed fields; names and sources added in a correction are additive, and a renamed record keeps its old name as a searchable alternate.

## 7. Search

FTS5 table `search_fts`, one row per **public** entity: normalized title, all normalized names/aliases, and body text. Normalization folds case and diacritics, drops apostrophe variants (so *Ghebre'ab* = *Ghebreab*), and keeps Ge'ez and Arabic letters. Queries use prefix matching on every token, rank title and alias matches above body text, re-check `PUBLIC_WHERE` (so a stale index row can never leak), report which alternate name matched, and offer "did you mean" suggestions from public names only.

## 8. Security summary

Server-side permission checks on every route (`security.require`) and again inside services; CSRF tokens on every POST; session token rotation on login; logout and password changes revoke sessions in the database; login rate limiting per account and per network address with timing equalisation; no account enumeration on reset; open-redirect protection; strict Content-Security-Policy with no inline code; `X-Frame-Options: DENY`; `no-store` on every personalised or private response; parameterised SQL throughout; Jinja auto-escaping; secrets never logged. Production refuses to start with the development secret or a non-https base URL.

## 9. Page and route inventory

**Public**
| Route | Purpose |
| --- | --- |
| `/` | Home: mission, category cards with real counts, timeline preview, contribution call |
| `/people`, `/families`, `/places`, `/events`, `/sources` | Paginated lists with A–Z filter |
| `/people/<slug>` … `/sources/<slug>` | Record pages; old slugs 301-redirect |
| `/id/<permanent-id>` | Permanent identifier resolver (follows merges) |
| `/search?q=&type=` | Global search |
| `/timeline` | Chronological events by decade; undated events listed separately |
| `/map` | List alternative now; interactive map in Milestone 3 |
| `/archive`, `/oral-histories`, `/community` | Honest "not open yet" pages (Milestones 4–5) |
| `/about`, `/standards`, `/how-to-contribute`, `/corrections`, `/privacy`, `/terms`, `/copyright`, `/accessibility`, `/data-policy`, `/contact` | Information pages and contact form |
| `/robots.txt`, `/sitemap.xml` | Crawling (public, non-fictional records only) |

**Authentication** — `/auth/register`, `/auth/login`, `POST /auth/logout`, `/auth/verify/<token>`, `POST /auth/resend-verification`, `/auth/forgot`, `/auth/reset/<token>`; development only: `/dev/outbox`.

**Contributor** — `/dashboard`, `/dashboard/submissions`, `/dashboard/submissions/<id>`, `…/<id>/edit`, `POST …/<id>/submit`, `POST …/<id>/withdraw`, `/contribute/<person|family|place|event|source>`, `/contribute/correction/<permanent-id>`, `/contribute/relationship?family=<id>`, `/dashboard/profile`, `/dashboard/password`, `/dashboard/notifications`.

**Editorial** — `/editor` (queue tabs and flags), `/editor/submissions/<id>` (review), `POST …/transition`, `POST …/note`, `/editor/records`, `/editor/records/<permanent-id>` (staff view), `POST …/state`, `POST …/slug`, `POST /editor/families/<id>/representatives`, `POST …/representatives/<gid>/revoke`, `/editor/messages`, `POST /editor/messages/<id>/handled`.

**Administration** — `/admin` (operational overview), `/admin/users`, `/admin/users/<id>`, `POST …/roles`, `POST …/<deactivate|reactivate|anonymize|verify>`, `/admin/audit`, `/admin/taxonomies`.

## 10. Planned components (later milestones)

**Map (Milestone 3).** Leaflet (BSD-2 licence), vendored into `static/` so the strict CSP stays intact. Marker data comes from the same `places` table via a public JSON endpoint filtered by `PUBLIC_WHERE`. Approximate points are drawn with a different marker and an uncertainty note; places without coordinates are never placed. Tiles need a provider decision (see `STATUS.md`). No historical boundary data will be drawn unless a licensed, sourced dataset is supplied.

**Media (Milestone 4).** Files stored outside any web-served path under generated names; content-type sniffing with Pillow/ffmpeg, size limits, SHA-256 checksums, originals preserved and derivatives linked to them. Downloads go through an authorising route (and signed URLs once on S3-compatible storage). Rights status and access level are checked separately from the record's own visibility.

**Oral histories (Milestone 4).** Per-type consent rows gate each kind of publication (recording, transcript, translation, excerpts, download). Machine transcripts are stored as `machine_draft` and labelled as drafts.

**Forum (Milestone 5).** Database-backed categories, topics and posts; reporting, moderation actions log, rate limits, and conversion of a discussion into an archive submission only through the editorial workflow.

## 11. Milestones

| # | Scope | Depends on | Done when |
| --- | --- | --- | --- |
| 1 | Schema, migrations, auth, roles, editorial workflow, design system, record pages, search, admin foundation | — | A user can register, sign in and submit; an editor can review and publish; the record appears on public pages and in search; permissions hold under forged requests |
| 2 | Duplicate merging, editor-side citation and conflicting-account management, affiliations and organizations, family memberships and event participants via the workflow, CSV import with preview | 1 | Records connect through shared entities and approved changes appear on all related pages |
| 3 | Interactive map, timeline filters, family tree viewer and list alternative, relationship network | 2 | Map and timeline lead to real records only; tree uses relationship rows; accessible alternatives exist |
| 4 | Secure uploads, storage, previews, rights, collections, oral histories with consent | 1 (+ storage decision) | Only approved and permitted media is reachable, including by guessed URL |
| 5 | Forum, reports, moderation, notification preferences | 1 | Forum activity is persisted, moderated and separate from archive records |
| 6 | Exports, multilingual interface (Tigrinya, Arabic with RTL), accessibility and security review, deployment and handover guides | 1–5 | Someone other than the original developer can install, operate, back up and restore it |

## 12. Testing strategy

- **Unit and service tests** (`tests/test_services.py`): dates, names, schema constraints, workflow rules, publication atomicity, living-person protection, relationships, family-representative scope, duplicates, slugs.
- **HTTP integration tests** (`tests/test_http.py`): the real routes with forged requests (role escalation, editing others' submissions, rep publishing), leak checks across every public surface, CSRF, sessions, lockout, open redirects, headers, verification and reset flows, production config.
- **Browser end-to-end** (`tests/e2e_browser.py`): Chromium through the full submit → revise → publish → search flow, mobile menu and overflow, keyboard skip link.
