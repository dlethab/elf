"""CSRF, security headers, safe redirects, caching policy, staff-route guards."""
import hmac
import secrets
from functools import wraps
from urllib.parse import urlparse

from flask import abort, g, redirect, request, session, url_for

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


def check_csrf():
    if request.method in UNSAFE:
        sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token") or ""
        expected = session.get("csrf") or ""
        if not expected or not hmac.compare_digest(sent, expected):
            abort(400, description="Your session expired or the form was invalid. Please go back, reload, and try again.")


def safe_next(target, default="/"):
    """Only same-site relative paths; blocks open redirects such as //evil.test or https://evil.test."""
    if not target:
        return default
    u = urlparse(target)
    if u.scheme or u.netloc or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return default
    return target


def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if not g.get("user"):
            return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
        return view(*a, **kw)
    return wrapped


def require(permission):
    """Server-side permission gate. Anonymous → login; signed in without permission → 403."""
    def deco(view):
        @wraps(view)
        def wrapped(*a, **kw):
            if not g.get("user"):
                return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
            if not g.user.can(permission):
                abort(403)
            return view(*a, **kw)
        return wrapped
    return deco


CSP = ("default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
       "frame-ancestors 'none'; form-action 'self'; base-uri 'none'; object-src 'none'")
PRIVATE_PREFIXES = ("/dashboard", "/editor", "/admin", "/auth", "/dev", "/contribute")


def apply_headers(response):
    h = response.headers
    h["Content-Security-Policy"] = CSP
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "DENY"
    h["Referrer-Policy"] = "strict-origin-when-cross-origin"
    h["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()"
    h.add("Vary", "Cookie")
    # Anything personalised, or any non-GET, is never cacheable. Anonymous public GETs must revalidate,
    # so an unpublished record cannot linger in a shared cache.
    if g.get("user") or request.method != "GET" or request.path.startswith(PRIVATE_PREFIXES):
        h["Cache-Control"] = "private, no-store"
    elif request.path.startswith("/static/"):
        h.setdefault("Cache-Control", "public, max-age=3600")
    else:
        h["Cache-Control"] = "public, max-age=0, must-revalidate"
    if request.path.startswith(PRIVATE_PREFIXES):
        h["X-Robots-Tag"] = "noindex, nofollow"
    return response
