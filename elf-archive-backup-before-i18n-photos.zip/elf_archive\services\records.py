"""Record specifications, validation, and application of approved submissions.

Contributions are validated into plain JSON (`proposed_data`). NOTHING is written to the entity
tables until an editor publishes the submission, at which point `apply_*` runs in one transaction.
"""
import re
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

from . import audit, dates, entities, search
from .dates import DATE_HELP
from .timeutil import now_iso
from ..vocab import (COORD_PRECISIONS, DIRECTED_RELATIONSHIPS, RELATIONSHIP_STATUSES,
                     RELATIONSHIP_TYPES, SOURCE_TYPES)


@dataclass
class F:
    name: str
    label: str
    kind: str = "text"      # text|area|choice|date|placeref|personref|taxon|lines|sources|float|url
    required: bool = False
    max: int = 200
    choices: Optional[list] = None
    help: str = ""
    rows: int = 4
    additive: bool = False  # corrections only ADD (aliases, sources) and never delete


SPECS = {
    "person": [
        F("preferred_name", "Preferred name", required=True),
        F("full_name", "Full name"),
        F("original_name", "Name in original script or language"),
        F("original_name_lang", "Language of that name (code, e.g. ti, ar, en)", max=16),
        F("aliases", "Other spellings, transliterations, aliases (one per line)", "lines", additive=True),
        F("occupation", "Occupation or civilian role", max=300),
        F("living_status", "Living status", "choice",
          choices=[("unknown", "Unknown"), ("deceased", "Deceased"), ("living", "Living")],
          help="People recorded as living are kept private until an editor confirms consent."),
        F("birth", "Birth", "date", help=DATE_HELP),
        F("birth_place", "Birthplace", "placeref", help="Choose from published places; leave blank if unknown."),
        F("death", "Death", "date", help=DATE_HELP),
        F("death_place", "Place of death", "placeref"),
        F("summary", "Short summary", "area", max=1000, rows=3),
        F("biography", "Biography and life history", "area", max=20000, rows=10),
    ],
    "family": [
        F("display_name", "Family name", required=True),
        F("original_name", "Name in original script or language"),
        F("aliases", "Other spellings (one per line)", "lines", additive=True),
        F("region_note", "Regions or towns of association", max=500),
        F("summary", "Short summary", "area", max=1000, rows=3),
        F("narrative", "Family history", "area", max=20000, rows=10),
    ],
    "place": [
        F("primary_name", "Primary name", required=True),
        F("original_name", "Name in original script or language"),
        F("aliases", "Historical names and alternate spellings (one per line)", "lines", additive=True),
        F("place_type", "Place type", "taxon"),
        F("country", "Country", max=100),
        F("admin_region", "Region / administrative area", max=200),
        F("latitude", "Latitude (decimal degrees)", "float",
          help="Only enter coordinates you can source. Leave blank if unknown — never estimate silently."),
        F("longitude", "Longitude (decimal degrees)", "float"),
        F("coord_precision", "Coordinate precision", "choice",
          choices=[("", "—")] + [(c, c.replace("_", " ").capitalize()) for c in COORD_PRECISIONS],
          help="Required when coordinates are given. 'Approximate' is shown to visitors as approximate."),
        F("coord_note", "Note on location uncertainty", "area", max=1000, rows=2),
        F("overview", "Historical overview", "area", max=20000, rows=8),
    ],
    "event": [
        F("title", "Event title", required=True),
        F("event_type", "Event type", "taxon"),
        F("date", "Date", "date", help=DATE_HELP),
        F("place", "Place", "placeref", help="Choose from published places; leave blank if unknown."),
        F("summary", "Short summary", "area", max=1000, rows=3),
        F("description", "Detailed account", "area", max=20000, rows=10),
    ],
    "source": [
        F("title", "Title", required=True, max=300),
        F("source_type", "Source type", "choice", choices=[(s, s.replace("_", " ").capitalize()) for s in SOURCE_TYPES]),
        F("creator", "Author or creator", max=300),
        F("publisher", "Publisher"),
        F("repository", "Repository or archive"),
        F("identifier", "Identifier or catalogue number"),
        F("pub_date_text", "Publication or creation date (free text)", max=100),
        F("url", "URL", "url", max=500),
        F("language", "Language", max=50),
        F("provenance", "Provenance", "area", max=2000, rows=3),
    ],
    "relationship": [
        F("person_a", "Person A", "personref", required=True),
        F("relationship_type", "Relationship (A is … of B)", "choice", required=True,
          choices=[(k, v[0]) for k, v in RELATIONSHIP_TYPES.items()]),
        F("person_b", "Person B", "personref", required=True),
        F("status", "Status", "choice", choices=[(s, s.capitalize()) for s in RELATIONSHIP_STATUSES]),
        F("period", "Dates, if relevant", "date", help=DATE_HELP),
        F("notes", "Explanation / notes", "area", max=2000, rows=3),
    ],
}
# Every content kind (except relationships) may carry contributor-declared sources.
SOURCES_FIELD = F("sources", "Supporting sources (one per line: Title | page or locator | URL)", "sources", additive=True,
                  help="Each line becomes a separate source record, cited as 'unverified' until an editor assesses it.")

TITLE_FIELD = {"person": "preferred_name", "family": "display_name", "place": "primary_name",
               "event": "title", "source": "title"}
NOT_NULL_DEFAULTS = {"living_status": "unknown", "source_type": "other", "status": "current"}
PLACE_COLUMN = {"birth_place": "birth_place_id", "death_place": "death_place_id"}
TAXON_TABLE = {"place_type": ("place_types", "place_type_id"), "event_type": ("event_types", "event_type_id")}
NAME_FIELD_TYPES = {"preferred_name": "preferred", "full_name": "full", "display_name": "preferred",
                    "primary_name": "preferred", "title": "preferred"}


def spec_for(kind, with_sources=True):
    fields = list(SPECS[kind])
    if with_sources and kind not in ("relationship", "source"):
        fields.append(SOURCES_FIELD)
    return fields


# ───────────── choices for select inputs ─────────────
def choices_for(db, f):
    if f.kind == "choice":
        return f.choices
    if f.kind == "taxon":
        table = TAXON_TABLE[f.name][0]
        return [("", "—")] + [(r["slug"], r["label"]) for r in
                              db.execute(f"SELECT slug, label FROM {table} WHERE is_active=1 ORDER BY sort_order")]
    if f.kind in ("placeref", "personref"):
        kind, col, tab = ("place", "primary_name", "places") if f.kind == "placeref" else ("person", "preferred_name", "people")
        rows = db.execute(f"SELECT e.public_id, t.{col} AS t FROM entities e JOIN {tab} t ON t.entity_id=e.id "
                          f"WHERE e.kind=? AND {entities.PUBLIC_WHERE} ORDER BY t.{col} LIMIT 1000", (kind,)).fetchall()
        return [("", "—")] + [(r["public_id"], r["t"]) for r in rows]
    return None


# ───────────── validation ─────────────
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _clean_text(v, multiline):
    v = _CTRL.sub("", (v or "").replace("\r\n", "\n").replace("\r", "\n"))
    return v.strip() if multiline else " ".join(v.split())


def _ok_url(v):
    u = urlparse(v)
    return u.scheme in ("http", "https") and bool(u.netloc)


def validate(db, kind, raw):
    """Return (clean, errors). `raw` is a mapping of form strings. Unknown keys are ignored."""
    clean, errors = {}, {}
    for f in spec_for(kind):
        v = raw.get(f.name, "")
        v = v if isinstance(v, str) else ("" if v is None else str(v))
        if f.kind in ("text", "area", "url"):
            v = _clean_text(v, f.kind == "area")
            if f.required and not v:
                errors[f.name] = "This field is required."
            elif len(v) > f.max:
                errors[f.name] = f"Use at most {f.max} characters."
            elif f.kind == "url" and v and not _ok_url(v):
                errors[f.name] = "Enter a full http(s) URL."
            clean[f.name] = v or None
        elif f.kind == "choice":
            v = v.strip()
            allowed = {c[0] for c in f.choices}
            if f.required and not v:
                errors[f.name] = "This field is required."
            elif v and v not in allowed:
                errors[f.name] = "Choose one of the listed options."
            clean[f.name] = v or None
        elif f.kind == "taxon":
            v = v.strip()
            if v and not db.execute(f"SELECT 1 FROM {TAXON_TABLE[f.name][0]} WHERE slug=? AND is_active=1", (v,)).fetchone():
                errors[f.name] = "Choose one of the listed options."
            clean[f.name] = v or None
        elif f.kind == "date":
            try:
                clean[f.name] = dates.parse(v).as_dict()
            except dates.DateError as e:
                errors[f.name] = str(e)
        elif f.kind in ("placeref", "personref"):
            v = v.strip()
            want = "place" if f.kind == "placeref" else "person"
            if f.required and not v:
                errors[f.name] = "This field is required."
            elif v and not entities.get_public_by_public_id(db, v, want):
                errors[f.name] = "That record was not found."        # uniform: never confirms private ids
            clean[f.name] = v or None
        elif f.kind == "float":
            v = v.strip()
            try:
                clean[f.name] = float(v) if v else None
            except ValueError:
                errors[f.name] = "Enter a number."
        elif f.kind == "lines":
            vals = [" ".join(x.split()) for x in _CTRL.sub("", v).splitlines() if x.strip()]
            if len(vals) > 30 or any(len(x) > 200 for x in vals):
                errors[f.name] = "At most 30 lines of up to 200 characters."
            clean[f.name] = vals
        elif f.kind == "sources":
            out = []
            for line in [x for x in _CTRL.sub("", v).splitlines() if x.strip()][:10]:
                parts = [p.strip() for p in line.split("|")]
                title, locator, url = (parts + ["", "", ""])[:3]
                if not title or len(title) > 300 or len(locator) > 200:
                    errors[f.name] = "Each source needs a title (≤300 chars) and a short locator."
                    break
                if url and not _ok_url(url):
                    errors[f.name] = "Source URLs must be full http(s) addresses."
                    break
                out.append({"title": title, "locator": locator or None, "url": url or None})
            clean[f.name] = out
    # cross-field rules
    if kind == "place" and not errors:
        la, lo, pr = clean.get("latitude"), clean.get("longitude"), clean.get("coord_precision")
        if (la is None) != (lo is None):
            errors["longitude"] = "Give both latitude and longitude, or neither."
        elif la is not None:
            if not -90 <= la <= 90:
                errors["latitude"] = "Latitude must be between -90 and 90."
            if not -180 <= lo <= 180:
                errors["longitude"] = "Longitude must be between -180 and 180."
            if not pr:
                errors["coord_precision"] = "Say how precise these coordinates are."
        elif pr:
            errors["coord_precision"] = "Precision applies only when coordinates are given."
    if kind == "relationship" and not errors:
        a, b = clean["person_a"], clean["person_b"]
        if a == b:
            errors["person_b"] = "A person cannot be related to themselves."
        elif _find_relationship(db, a, b, clean["relationship_type"]):
            errors["relationship_type"] = "This relationship is already recorded."
        clean["status"] = clean.get("status") or "current"
    return clean, errors


def _canonical_pair(a, b, rtype):
    return (a, b) if (rtype in DIRECTED_RELATIONSHIPS or a < b) else (b, a)


def _find_relationship(db, pub_a, pub_b, rtype):
    a, b = entities.get_by_public_id(db, pub_a), entities.get_by_public_id(db, pub_b)
    if not a or not b:
        return None
    x, y = _canonical_pair(a["id"], b["id"], rtype)
    return db.execute("SELECT id FROM relationships WHERE person_a_id=? AND person_b_id=? AND relationship_type=?",
                      (x, y, rtype)).fetchone()


# ───────────── column mapping ─────────────
def _row_values(db, kind, clean, fields=None):
    """Map validated fields to subtype-table columns."""
    cols = {}
    for f in spec_for(kind, with_sources=False):
        if fields is not None and f.name not in fields:
            continue
        if f.kind in ("lines", "sources") or f.name not in clean:
            continue
        v = clean[f.name]
        if f.kind == "date":
            cols.update(dates.columns(f.name, dates.FuzzyDate(**v)))
        elif f.kind == "placeref" and f.name in PLACE_COLUMN:
            cols[PLACE_COLUMN[f.name]] = (entities.get_by_public_id(db, v)["id"] if v else None)
        elif f.kind == "placeref":      # event.place → event_places (handled separately)
            continue
        elif f.kind == "taxon":
            table, col = TAXON_TABLE[f.name]
            cols[col] = (db.execute(f"SELECT id FROM {table} WHERE slug=?", (v,)).fetchone()["id"] if v else None)
        else:
            cols[f.name] = NOT_NULL_DEFAULTS[f.name] if (v is None and f.name in NOT_NULL_DEFAULTS) else v
    return cols


def current_clean(db, kind, entity_id):
    """Current stored values in the same shape `validate` produces (used for diffs and prefilled forms)."""
    row = entities.subtype_row(db, entity_id)
    out = {}
    for f in spec_for(kind, with_sources=False):
        if f.kind in ("lines", "sources"):
            out[f.name] = []
        elif f.kind == "date":
            out[f.name] = dates.from_row(row, f.name).as_dict()
        elif f.kind == "placeref" and f.name in PLACE_COLUMN:
            pid = row[PLACE_COLUMN[f.name]]
            out[f.name] = entities.get(db, pid)["public_id"] if pid else None
        elif f.kind == "placeref":
            r = db.execute("SELECT e.public_id FROM event_places ep JOIN entities e ON e.id=ep.place_id "
                           "WHERE ep.event_id=? ORDER BY ep.id LIMIT 1", (entity_id,)).fetchone()
            out[f.name] = r["public_id"] if r else None
        elif f.kind == "taxon":
            table, col = TAXON_TABLE[f.name]
            r = db.execute(f"SELECT slug FROM {table} WHERE id=?", (row[col],)).fetchone() if row[col] else None
            out[f.name] = r["slug"] if r else None
        else:
            out[f.name] = row[f.name]
    return out


def form_values(clean, kind):
    """Turn validated/stored data back into form strings (for re-displaying a draft)."""
    out = {}
    for f in spec_for(kind):
        v = clean.get(f.name)
        if v in (None, [], {}):
            out[f.name] = ""
        elif f.kind == "date":
            out[f.name] = dates.to_input(v["start"], v["end"], v["precision"])
        elif f.kind == "lines":
            out[f.name] = "\n".join(v)
        elif f.kind == "sources":
            out[f.name] = "\n".join(" | ".join(x for x in (s["title"], s.get("locator") or "", s.get("url") or "")).rstrip(" |")
                                    for s in v)
        elif f.kind == "float":
            out[f.name] = repr(v)
        else:
            out[f.name] = str(v)
    return out


def display_value(db, f, v):
    if v in (None, "", [], {}):
        return "—"
    if f.kind == "date":
        return dates.format_date(v["start"], v["end"], v["precision"])
    if f.kind in ("placeref", "personref"):
        e = entities.get_by_public_id(db, v)
        return entities.title_of(db, e["id"]) if e else v
    if f.kind in ("choice", "taxon"):
        for val, label in (choices_for(db, f) or []):
            if val == v:
                return label
        return str(v)
    if f.kind == "lines":
        return "; ".join(v)
    if f.kind == "sources":
        return "; ".join(s["title"] + (f" ({s['locator']})" if s.get("locator") else "") for s in v)
    return str(v)


def display_rows(db, kind, data):
    """[(label, value)] for a proposed new record, skipping empty fields."""
    rows = []
    for f in spec_for(kind):
        v = display_value(db, f, data.get(f.name))
        if v != "—" and not (f.kind == "date" and v == "Unknown"):
            rows.append((f.label, v))
    return rows


def diff(db, kind, entity_id, changes):
    cur = current_clean(db, kind, entity_id)
    byname = {f.name: f for f in spec_for(kind)}
    return [{"label": byname[n].label, "old": display_value(db, byname[n], cur.get(n)),
             "new": display_value(db, byname[n], new), "additive": byname[n].additive}
            for n, new in changes.items() if n in byname]


def changed_fields(db, kind, entity_id, clean):
    """Reduce a full validated form to only what differs from the stored record."""
    cur = current_clean(db, kind, entity_id)
    out = {}
    for f in spec_for(kind):
        v = clean.get(f.name)
        if f.additive:
            if v:
                out[f.name] = v
        elif v != cur.get(f.name) and not (v in (None, "") and cur.get(f.name) in (None, "")):
            out[f.name] = v
    return out


# ───────────── applying approved submissions ─────────────
def _store_sources(db, target_id, sources, actor_id, field=None):
    for s in sources or []:
        existing = db.execute(
            "SELECT s.entity_id FROM sources s JOIN entities e ON e.id=s.entity_id "
            "WHERE lower(s.title)=lower(?) AND COALESCE(s.url,'')=COALESCE(?, '') AND e.merged_into IS NULL",
            (s["title"], s["url"])).fetchone()
        if existing:
            sid = existing["entity_id"]     # reuse: one source can support claims on many records
        else:
            sid, _, _ = entities.create_entity(db, "source", s["title"], created_by=actor_id,
                                               status="published", visibility="public")
            db.execute("INSERT INTO sources(entity_id, title, url) VALUES (?,?,?)", (sid, s["title"], s["url"]))
            entities.add_name(db, sid, s["title"], "preferred")
            entities.add_revision(db, sid, actor_id, "Source created from approved contribution")
            search.reindex(db, sid)
        db.execute("INSERT INTO citations(source_id, target_id, field_name, locator, evidence_status, created_by) "
                   "VALUES (?,?,?,?, 'unverified', ?)", (sid, target_id, field, s.get("locator"), actor_id))


def _add_names(db, entity_id, kind, clean):
    for f in spec_for(kind, with_sources=False):
        v = clean.get(f.name)
        if not v:
            continue
        if f.name in NAME_FIELD_TYPES:
            entities.add_name(db, entity_id, v, NAME_FIELD_TYPES[f.name])
        elif f.name == "original_name":
            entities.add_name(db, entity_id, v, "original", language=clean.get("original_name_lang"))
        elif f.name == "aliases":
            for a in v:
                entities.add_name(db, entity_id, a, "alternate_spelling")


def apply_new(db, kind, clean, *, actor_id, submission_id, consent_confirmed=False, fictional=False):
    """Create a published record from validated data. Caller supplies the surrounding transaction."""
    living = kind == "person" and clean.get("living_status") == "living"
    visibility = "restricted" if (living and not consent_confirmed) else "public"
    title = clean[TITLE_FIELD[kind]]
    eid, pid, _ = entities.create_entity(db, kind, title, created_by=actor_id, status="published",
                                         visibility=visibility, fictional=fictional)
    cols = _row_values(db, kind, clean)
    keys = ["entity_id"] + list(cols)
    db.execute(f"INSERT INTO {entities.KIND_TABLE[kind]}({','.join(keys)}) VALUES ({','.join('?' * len(keys))})",
               [eid, *cols.values()])
    if kind == "event" and clean.get("place"):
        db.execute("INSERT INTO event_places(event_id, place_id) VALUES (?,?)",
                   (eid, entities.get_by_public_id(db, clean["place"])["id"]))
    _add_names(db, eid, kind, clean)
    _store_sources(db, eid, clean.get("sources"), actor_id)
    entities.add_revision(db, eid, actor_id, "Created from an approved submission", submission_id=submission_id)
    audit.log(db, actor_id, "record.published", kind, pid, {"submission": submission_id, "visibility": visibility})
    search.reindex(db, eid)
    return eid


def apply_correction(db, entity, changes, *, actor_id, submission_id, reason=None):
    kind, eid = entity["kind"], entity["id"]
    cols = _row_values(db, kind, changes, fields=set(changes))
    if cols:
        sets = ", ".join(f"{c}=?" for c in cols)
        db.execute(f"UPDATE {entities.KIND_TABLE[kind]} SET {sets} WHERE entity_id=?", [*cols.values(), eid])
    if kind == "event" and "place" in changes:
        db.execute("DELETE FROM event_places WHERE event_id=?", (eid,))
        if changes["place"]:
            db.execute("INSERT INTO event_places(event_id, place_id) VALUES (?,?)",
                       (eid, entities.get_by_public_id(db, changes["place"])["id"]))
    tf = TITLE_FIELD[kind]
    if tf in changes and changes[tf]:
        # keep the previous preferred spelling searchable as an alternate; never discard it
        db.execute("UPDATE OR IGNORE entity_names SET name_type='alternate_spelling' WHERE entity_id=? AND name_type='preferred'", (eid,))
        db.execute("DELETE FROM entity_names WHERE entity_id=? AND name_type='preferred'", (eid,))
        entities.add_name(db, eid, changes[tf], "preferred")
    if changes.get("full_name"):
        entities.add_name(db, eid, changes["full_name"], "full")
    if changes.get("original_name"):
        entities.add_name(db, eid, changes["original_name"], "original")
    for a in changes.get("aliases", []):
        entities.add_name(db, eid, a, "alternate_spelling")
    _store_sources(db, eid, changes.get("sources"), actor_id)
    labels = {f.name: f.label for f in spec_for(kind)}
    entities.add_revision(db, eid, actor_id, "Correction: " + ", ".join(labels[k] for k in changes),
                          reason=reason, submission_id=submission_id)
    db.execute("UPDATE entities SET updated_at=? WHERE id=?", (now_iso(), eid))
    audit.log(db, actor_id, "record.corrected", kind, entity["public_id"],
              {"fields": sorted(changes), "submission": submission_id})
    if kind == "person" and changes.get("living_status") == "living" and entity["visibility"] == "public":
        entities.set_state(db, eid, visibility="restricted", actor_id=actor_id,
                           reason="Automatically restricted: person recorded as living")
    search.reindex(db, eid)


def apply_relationship(db, clean, *, actor_id, submission_id):
    a = entities.get_public_by_public_id(db, clean["person_a"], "person")
    b = entities.get_public_by_public_id(db, clean["person_b"], "person")
    if not a or not b:
        raise ValueError("Both people must still be published.")
    x, y = _canonical_pair(a["id"], b["id"], clean["relationship_type"])
    living = any(entities.subtype_row(db, i)["living_status"] == "living" for i in (a["id"], b["id"]))
    fd = dates.FuzzyDate(**clean["period"])
    cols = {"person_a_id": x, "person_b_id": y, "relationship_type": clean["relationship_type"],
            "status": clean.get("status") or "current", "notes": clean.get("notes"), "publication_status": "published",
            "visibility": "restricted" if living else "public", "created_by": actor_id,
            "submission_id": submission_id, **dates.columns("period", fd)}
    cur = db.execute(f"INSERT INTO relationships({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", list(cols.values()))
    for p in (a, b):
        entities.add_revision(db, p["id"], actor_id, f"Relationship added ({clean['relationship_type'].replace('_', ' ')})",
                              submission_id=submission_id)
    audit.log(db, actor_id, "relationship.published", "relationship", cur.lastrowid, {"submission": submission_id})
    return cur.lastrowid
