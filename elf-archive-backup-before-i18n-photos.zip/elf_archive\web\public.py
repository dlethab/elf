"""Public, anonymous-safe pages. Every record lookup goes through entities.resolve_public / PUBLIC_WHERE,
so drafts, restricted (e.g. living) people and merged records 404 exactly like records that never existed."""
from flask import Blueprint, Response, abort, current_app, flash, g, redirect, render_template, request, url_for

from .. import queries
from ..db import get_db, tx
from ..services import dates, entities, ratelimit, search
from ..services.entities import PUBLIC_WHERE
from ..services.search import SEARCHABLE_KINDS
from ..vocab import KIND_LABELS

bp = Blueprint("public", __name__)

LIST_KINDS = {"people": "person", "families": "family", "places": "place", "events": "event", "sources": "source"}
SECTION_TITLES = {"person": "People", "family": "Families", "place": "Places", "event": "Events", "source": "Sources"}


def _page():
    try:
        return max(1, min(int(request.args.get("page", 1)), 10000))
    except ValueError:
        return 1


def _resolve(kind, slug):
    res = entities.resolve_public(get_db(), kind, slug)
    if res is None:
        abort(404)
    state, e = res
    if state == "redirect":
        return None, redirect(queries.record_url(kind, e["slug"]), 301)
    return e, None


@bp.route("/")
def home():
    db = get_db()
    return render_template("home.html", counts=queries.counts(db), events=queries.latest_events(db, 5))


@bp.route("/id/<public_id>")
def by_permanent_id(public_id):
    """Permanent identifier → current canonical URL (follows merges)."""
    e = entities.get_by_public_id(get_db(), public_id)
    if not e:
        abort(404)
    seen = set()
    while e["merged_into"] and e["id"] not in seen:
        seen.add(e["id"])
        e = entities.get(get_db(), e["merged_into"])
    pub = entities.get_public_by_public_id(get_db(), e["public_id"])
    if not pub or pub["kind"] not in entities.URL_SECTION or pub["kind"] not in SECTION_TITLES:
        abort(404)
    return redirect(queries.record_url(pub["kind"], pub["slug"]), 301)


# ───────────── lists ─────────────
def _list(section):
    kind = LIST_KINDS[section]
    letter = (request.args.get("letter") or "").strip().upper()[:1] or None
    rows, total = queries.list_public(get_db(), kind, _page(), letter)
    return render_template("records/list.html", kind=kind, section=section, title=SECTION_TITLES[kind],
                           rows=rows, total=total, page=_page(), per_page=queries.PER_PAGE, letter=letter)


for _section in LIST_KINDS:
    bp.add_url_rule(f"/{_section}", f"list_{_section}", (lambda s: lambda: _list(s))(_section))


# ───────────── record pages ─────────────
@bp.route("/people/<slug>")
def person(slug):
    e, r = _resolve("person", slug)
    if r:
        return r
    db = get_db()
    p = queries.sub(db, e["id"], "person")
    return render_template("records/person.html", e=e, p=p, names=queries.names(db, e["id"]),
                           birth_place=queries.place_link(db, p["birth_place_id"]),
                           death_place=queries.place_link(db, p["death_place_id"]),
                           relationships=queries.person_relationships(db, e["id"]),
                           families=queries.person_families(db, e["id"]), events=queries.person_events(db, e["id"]),
                           cites=queries.citations(db, e["id"]), accts=queries.accounts(db, e["id"]),
                           revisions=queries.public_revisions(db, e["id"]))


@bp.route("/families/<slug>")
def family(slug):
    e, r = _resolve("family", slug)
    if r:
        return r
    db = get_db()
    return render_template("records/family.html", e=e, f=queries.sub(db, e["id"], "family"), names=queries.names(db, e["id"]),
                           members=queries.family_members(db, e["id"]), cites=queries.citations(db, e["id"]),
                           accts=queries.accounts(db, e["id"]), revisions=queries.public_revisions(db, e["id"]),
                           can_propose=_can_propose_for(e))


def _can_propose_for(fam):
    if not g.get("user"):
        return False
    if g.user.can("record.view_any"):
        return True
    from ..services import families
    grant = families.active_grant(get_db(), g.user.id, fam["id"])
    return bool(grant and grant["can_propose_tree"])


@bp.route("/places/<slug>")
def place(slug):
    e, r = _resolve("place", slug)
    if r:
        return r
    db = get_db()
    p = queries.sub(db, e["id"], "place")
    ptype = db.execute("SELECT label FROM place_types WHERE id=?", (p["place_type_id"],)).fetchone() if p["place_type_id"] else None
    return render_template("records/place.html", e=e, p=p, ptype=ptype, names=queries.names(db, e["id"]),
                           events=queries.place_events(db, e["id"]), people=queries.place_people(db, e["id"]),
                           cites=queries.citations(db, e["id"]), accts=queries.accounts(db, e["id"]),
                           revisions=queries.public_revisions(db, e["id"]))


@bp.route("/events/<slug>")
def event(slug):
    e, r = _resolve("event", slug)
    if r:
        return r
    db = get_db()
    ev = queries.sub(db, e["id"], "event")
    etype = db.execute("SELECT label FROM event_types WHERE id=?", (ev["event_type_id"],)).fetchone() if ev["event_type_id"] else None
    return render_template("records/event.html", e=e, ev=ev, etype=etype, names=queries.names(db, e["id"]),
                           places=queries.event_places_for(db, e["id"]), participants=queries.event_participants(db, e["id"]),
                           cites=queries.citations(db, e["id"]), accts=queries.accounts(db, e["id"]),
                           revisions=queries.public_revisions(db, e["id"]))


@bp.route("/sources/<slug>")
def source(slug):
    e, r = _resolve("source", slug)
    if r:
        return r
    db = get_db()
    return render_template("records/source.html", e=e, s=queries.sub(db, e["id"], "source"),
                           cited_by=queries.cited_by(db, e["id"]), revisions=queries.public_revisions(db, e["id"]))


# ───────────── discovery ─────────────
@bp.route("/search")
def search_page():
    q = (request.args.get("q") or "").strip()[:200]
    kind = request.args.get("type") or None
    if kind not in SEARCHABLE_KINDS:
        kind = None
    res = search.search(get_db(), q, kind=kind, page=_page()) if q else None
    return render_template("search.html", q=q, kind=kind, res=res, kinds=SEARCHABLE_KINDS, kind_labels=KIND_LABELS)


@bp.route("/timeline")
def timeline():
    dated, undated = queries.timeline(get_db())
    groups = []
    for ev in dated:
        decade = f"{ev['date_start'][:3]}0s"
        if not groups or groups[-1][0] != decade:
            groups.append((decade, []))
        groups[-1][1].append(ev)
    return render_template("timeline.html", groups=groups, undated=undated)


@bp.route("/map")
def map_page():
    db = get_db()
    rows = db.execute(
        f"SELECT e.slug, e.is_fictional_test, p.primary_name, p.latitude, p.longitude, p.coord_precision, p.admin_region, p.country "
        f"FROM entities e JOIN places p ON p.entity_id=e.id WHERE e.kind='place' AND {PUBLIC_WHERE} ORDER BY lower(p.primary_name)").fetchall()
    return render_template("map.html", located=[r for r in rows if r["latitude"] is not None],
                           unlocated=[r for r in rows if r["latitude"] is None])


@bp.route("/archive")
@bp.route("/oral-histories")
@bp.route("/community")
def not_yet_open():
    section = {"/archive": "Digital Archive", "/oral-histories": "Oral Histories", "/community": "Community"}[request.path]
    return render_template("pages/not_yet_open.html", section=section)


# ───────────── static information pages ─────────────
INFO_PAGES = {"about": "About the archive", "standards": "Historical and editorial standards",
              "how-to-contribute": "How to contribute", "corrections": "How to submit corrections",
              "privacy": "Privacy policy", "terms": "Terms of use", "copyright": "Copyright and permissions",
              "accessibility": "Accessibility statement", "data-policy": "Data and licensing policy"}


@bp.route("/<any(" + ",".join(f'"{p}"' for p in INFO_PAGES) + "):page>")
def info(page):
    return render_template(f"pages/{page}.html", title=INFO_PAGES[page])


@bp.route("/contact", methods=["GET", "POST"])
def contact():
    db = get_db()
    about = (request.values.get("about") or "").strip()[:40]
    errors, values = {}, {"name": "", "email": "", "message": "", "about": about}
    if request.method == "POST":
        values.update({k: (request.form.get(k) or "").strip() for k in ("name", "email", "message")})
        if request.form.get("website"):            # honeypot: bots fill it, people don't see it
            flash("Thank you. Your message has been received.", "ok")
            return redirect(url_for("public.home"))
        if not 10 <= len(values["message"]) <= 5000:
            errors["message"] = "Write between 10 and 5,000 characters."
        if values["email"] and "@" not in values["email"]:
            errors["email"] = "Enter a valid email address, or leave it blank."
        if not errors:
            ip = request.remote_addr or "?"
            with tx(db):
                if not ratelimit.allow(db, f"contact:{ip}", 5, 3600):
                    abort(429)
                pub_ok = about if (about and entities.get_public_by_public_id(db, about)) else None
                db.execute("INSERT INTO contact_messages(name, email, message, related_public_id) VALUES (?,?,?,?)",
                           (values["name"][:120] or None, values["email"][:200] or None, values["message"], pub_ok))
            flash("Thank you. Your message has been received and will be read by the editorial team.", "ok")
            return redirect(url_for("public.home"))
    return render_template("pages/contact.html", title="Contact", errors=errors, values=values)


# ───────────── machine-readable ─────────────
@bp.route("/robots.txt")
def robots():
    base = current_app.config["BASE_URL"]
    body = ("User-agent: *\nDisallow: /dashboard\nDisallow: /editor\nDisallow: /admin\nDisallow: /auth\n"
            f"Disallow: /contribute\nDisallow: /dev\nSitemap: {base}/sitemap.xml\n")
    return Response(body, mimetype="text/plain")


@bp.route("/sitemap.xml")
def sitemap():
    base = current_app.config["BASE_URL"]
    entries = [e for e in queries.sitemap_entries(get_db())]
    rows = "".join(f"<url><loc>{base}{queries.record_url(e['kind'], e['slug'])}</loc><lastmod>{e['updated_at'][:10]}</lastmod></url>"
                   for e in entries)
    xml = f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{rows}</urlset>'
    return Response(xml, mimetype="application/xml")
