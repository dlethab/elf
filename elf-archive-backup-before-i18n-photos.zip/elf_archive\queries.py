"""Read-side queries for PUBLIC pages. Every query goes through PUBLIC_WHERE; confidential columns
(research_notes, editor notes) are never selected here."""
from .services import dates
from .services.entities import KIND_TABLE, PUBLIC_WHERE, SUMMARY_COL, TITLE_COL, URL_SECTION
from .vocab import RELATIONSHIP_TYPES

PER_PAGE = 24

# PUBLIC_WHERE written against a different table alias.
def _pub(alias):
    return PUBLIC_WHERE.replace("e.", f"{alias}.")


def record_url(kind, slug):
    return f"/{URL_SECTION[kind]}/{slug}"


def list_public(db, kind, page=1, letter=None):
    t, title, summ = KIND_TABLE[kind], TITLE_COL[kind], SUMMARY_COL[kind]
    where, args = f"e.kind=? AND {PUBLIC_WHERE}", [kind]
    if letter:
        where += f" AND upper(substr(t.{title},1,1))=?"
        args.append(letter)
    total = db.execute(f"SELECT COUNT(*) FROM entities e JOIN {t} t ON t.entity_id=e.id WHERE {where}", args).fetchone()[0]
    sel = f"t.{summ} AS summary_text," if summ else "NULL AS summary_text,"
    rows = db.execute(
        f"SELECT e.public_id, e.slug, e.is_fictional_test, t.{title} AS title, {sel} t.* "
        f"FROM entities e JOIN {t} t ON t.entity_id=e.id WHERE {where} "
        f"ORDER BY lower(t.{title}), e.id LIMIT ? OFFSET ?", args + [PER_PAGE, (max(page, 1) - 1) * PER_PAGE]).fetchall()
    return rows, total


def sub(db, entity_id, kind):
    return db.execute(f"SELECT * FROM {KIND_TABLE[kind]} WHERE entity_id=?", (entity_id,)).fetchone()


def names(db, entity_id):
    return db.execute("SELECT name, name_type, language FROM entity_names WHERE entity_id=? AND name_type<>'preferred' ORDER BY id",
                      (entity_id,)).fetchall()


def citations(db, entity_id):
    return db.execute(
        f"SELECT c.field_name, c.claim_text, c.locator, c.explanation, c.evidence_status, s.title, s.source_type, "
        f"s.creator, s.url, se.slug AS source_slug FROM citations c JOIN entities se ON se.id=c.source_id AND {_pub('se')} "
        f"JOIN sources s ON s.entity_id=se.id WHERE c.target_id=? ORDER BY c.id", (entity_id,)).fetchall()


def cited_by(db, source_id):
    """Public records that cite a source."""
    out = []
    for r in db.execute(f"SELECT DISTINCT e.id, e.kind, e.slug, c.locator FROM citations c JOIN entities e ON e.id=c.target_id "
                        f"AND {PUBLIC_WHERE} WHERE c.source_id=? ORDER BY e.kind, e.id", (source_id,)).fetchall():
        t = db.execute(f"SELECT {TITLE_COL[r['kind']]} AS t FROM {KIND_TABLE[r['kind']]} WHERE entity_id=?", (r["id"],)).fetchone()
        out.append({"kind": r["kind"], "url": record_url(r["kind"], r["slug"]), "title": t["t"], "locator": r["locator"]})
    return out


def accounts(db, entity_id):
    return db.execute("SELECT topic, account_text, attributed_to, basis_note, needs_research FROM conflicting_accounts "
                      "WHERE entity_id=? AND is_public=1 ORDER BY id", (entity_id,)).fetchall()


def public_revisions(db, entity_id):
    """Public change history: date and summary only. No actor identities, reasons or snapshots."""
    return db.execute("SELECT revision_number, change_summary, created_at FROM revisions WHERE entity_id=? ORDER BY revision_number DESC",
                      (entity_id,)).fetchall()


def person_relationships(db, person_id):
    out = []
    rows = db.execute(
        "SELECT r.*, (r.person_a_id=?) AS viewer_is_a FROM relationships r WHERE (r.person_a_id=? OR r.person_b_id=?) "
        "AND r.publication_status='published' AND r.visibility='public'", (person_id,) * 3).fetchall()
    for r in rows:
        other = r["person_b_id"] if r["viewer_is_a"] else r["person_a_id"]
        o = db.execute(f"SELECT e.public_id, e.slug, p.preferred_name FROM entities e JOIN people p ON p.entity_id=e.id "
                       f"WHERE e.id=? AND {PUBLIC_WHERE}", (other,)).fetchone()
        if not o:   # relationship to a non-public person is never revealed
            continue
        labels = RELATIONSHIP_TYPES[r["relationship_type"]]
        out.append({"label": labels[0] if r["viewer_is_a"] else labels[1], "status": r["status"], "notes": r["notes"],
                    "period": dates.format_date(r["period_start"], r["period_end"], r["period_precision"]),
                    "name": o["preferred_name"], "url": record_url("person", o["slug"])})
    return out


def person_families(db, person_id):
    return db.execute(
        f"SELECT e.slug, f.display_name, m.role_note FROM family_memberships m JOIN entities e ON e.id=m.family_id AND {PUBLIC_WHERE} "
        f"JOIN families f ON f.entity_id=e.id WHERE m.person_id=? AND m.publication_status='published' AND m.visibility='public'",
        (person_id,)).fetchall()


def person_events(db, person_id):
    return db.execute(
        f"SELECT e.slug, ev.title, ev.date_start, ev.date_end, ev.date_precision, p.role, p.evidence_status FROM event_participants p "
        f"JOIN entities e ON e.id=p.event_id AND {PUBLIC_WHERE} JOIN events ev ON ev.entity_id=e.id "
        f"WHERE p.person_id=? AND p.publication_status='published' ORDER BY ev.date_start", (person_id,)).fetchall()


def place_link(db, place_id):
    if not place_id:
        return None
    return db.execute(f"SELECT e.slug, p.primary_name FROM entities e JOIN places p ON p.entity_id=e.id WHERE e.id=? AND {PUBLIC_WHERE}",
                      (place_id,)).fetchone()


def family_members(db, family_id):
    return db.execute(
        f"SELECT e.slug, p.preferred_name, m.role_note FROM family_memberships m JOIN entities e ON e.id=m.person_id AND {PUBLIC_WHERE} "
        f"JOIN people p ON p.entity_id=e.id WHERE m.family_id=? AND m.publication_status='published' AND m.visibility='public' "
        f"ORDER BY p.preferred_name", (family_id,)).fetchall()


def place_events(db, place_id):
    return db.execute(
        f"SELECT e.slug, ev.title, ev.date_start, ev.date_end, ev.date_precision, ep.is_uncertain FROM event_places ep "
        f"JOIN entities e ON e.id=ep.event_id AND {PUBLIC_WHERE} JOIN events ev ON ev.entity_id=e.id WHERE ep.place_id=? "
        f"ORDER BY ev.date_start", (place_id,)).fetchall()


def place_people(db, place_id):
    return db.execute(
        f"SELECT e.slug, p.preferred_name, (p.birth_place_id=?) AS born, (p.death_place_id=?) AS died FROM people p "
        f"JOIN entities e ON e.id=p.entity_id AND {PUBLIC_WHERE} WHERE p.birth_place_id=? OR p.death_place_id=? "
        f"ORDER BY p.preferred_name", (place_id,) * 4).fetchall()


def event_participants(db, event_id):
    return db.execute(
        f"SELECT e.slug, p.preferred_name AS name, ep.role, ep.evidence_status FROM event_participants ep "
        f"JOIN entities e ON e.id=ep.person_id AND {PUBLIC_WHERE} JOIN people p ON p.entity_id=e.id "
        f"WHERE ep.event_id=? AND ep.publication_status='published' ORDER BY p.preferred_name", (event_id,)).fetchall()


def event_places_for(db, event_id):
    return db.execute(
        f"SELECT e.slug, p.primary_name, ep.is_uncertain, p.latitude, p.coord_precision FROM event_places ep "
        f"JOIN entities e ON e.id=ep.place_id AND {PUBLIC_WHERE} JOIN places p ON p.entity_id=e.id WHERE ep.event_id=?",
        (event_id,)).fetchall()


def timeline(db):
    """All public events, dated ones in order, undated ones listed separately (never given a false date)."""
    rows = db.execute(
        f"SELECT e.slug, e.is_fictional_test, ev.title, ev.summary, ev.date_start, ev.date_end, ev.date_precision, t.label AS type_label "
        f"FROM entities e JOIN events ev ON ev.entity_id=e.id LEFT JOIN event_types t ON t.id=ev.event_type_id "
        f"WHERE e.kind='event' AND {PUBLIC_WHERE} ORDER BY ev.date_start IS NULL, ev.date_start, lower(ev.title)").fetchall()
    dated = [r for r in rows if r["date_precision"] != "unknown"]
    undated = [r for r in rows if r["date_precision"] == "unknown"]
    return dated, undated


def latest_events(db, limit=5):
    return db.execute(
        f"SELECT e.slug, ev.title, ev.summary, ev.date_start, ev.date_end, ev.date_precision FROM entities e JOIN events ev ON ev.entity_id=e.id "
        f"WHERE e.kind='event' AND {PUBLIC_WHERE} AND ev.date_precision<>'unknown' ORDER BY ev.date_start LIMIT ?", (limit,)).fetchall()


def counts(db):
    """Real counts of PUBLIC records. Never fabricated."""
    return {r["kind"]: r["n"] for r in db.execute(
        f"SELECT e.kind, COUNT(*) AS n FROM entities e WHERE {PUBLIC_WHERE} GROUP BY e.kind")}


def sitemap_entries(db):
    return db.execute(f"SELECT e.kind, e.slug, e.updated_at FROM entities e WHERE {PUBLIC_WHERE} AND e.is_fictional_test=0 "
                      f"AND e.kind IN ('person','family','place','event','source') ORDER BY e.kind, e.id LIMIT 50000").fetchall()
