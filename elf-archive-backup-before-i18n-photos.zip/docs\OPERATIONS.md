# Operations: backup, restore, upgrade, troubleshooting

## Backups

The whole archive (records, users, history) is one SQLite file (`ELF_DATABASE_PATH`). Media files will be a second location from Milestone 4.

**Take a backup** (safe while the site is running; uses SQLite's online backup API and then runs an integrity check):

```bash
flask --app elf_archive backup /backups/archive-$(date +%Y%m%d-%H%M).db
```

Recommended policy, to be confirmed by the archive's governing body:
- Daily backups kept 14 days, weekly kept 3 months, monthly kept indefinitely.
- Encrypt backups before they leave the server (for example `age` or `gpg`), because they contain account emails and restricted records.
- Keep at least one copy with a different provider and under a different account owner than the web host, so the archive never depends on one person or one provider (spec §22.5).
- Recovery objectives (suggested): lose at most one day of data; restore within one working day.

**Test a restore at least quarterly:**

```bash
cp /backups/archive-YYYYMMDD-HHMM.db /tmp/restore-test.db
ELF_DATABASE_PATH=/tmp/restore-test.db flask --app elf_archive migrate      # applies any newer migrations
ELF_DATABASE_PATH=/tmp/restore-test.db flask --app elf_archive run --port 5001
```

Check that a few known records, search and sign-in work, then delete the test copy.

**Restore for real:** stop the app, keep the damaged file aside, copy the backup to `ELF_DATABASE_PATH`, run `migrate`, run `reindex`, start the app.

## Upgrades

1. Take a backup.
2. Deploy the new code.
3. `flask --app elf_archive migrate` (migrations are numbered, applied once, each in its own transaction).
4. Restart the app server.

## Moving to another host

Copy the database file (and, later, the media store) and the `.env` settings. Nothing else holds state.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| App will not start in production | `ELF_SECRET_KEY` must be 32+ random characters and `ELF_BASE_URL` must start with `https://` |
| Users never receive email | Set `ELF_SMTP_*`, then run `flask --app elf_archive send-email`; failures are recorded per message in the `outbox` table (admin overview shows the count) |
| "Your session expired or the form was invalid" | The form's CSRF token is older than the session; reload the page |
| A record is published but not in search | `flask --app elf_archive reindex` |
| A person was published but is not visible | They are recorded as living and were published as restricted; an editor can change access on the staff record page after confirming consent |
| "database is locked" under load | Expected only with very high write volume; consider the PostgreSQL migration path in ARCHITECTURE.md |
