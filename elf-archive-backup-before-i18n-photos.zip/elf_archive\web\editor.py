"""Editorial queue, review, publication and staff record management. Every route is gated by
security.require(<permission>); the workflow service re-checks permissions on every transition."""
import json

from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, url_for

from ..db import get_db, tx
from ..security import require
from ..services import audit, duplicates, entities, families, records, workflow
from ..services.entities import KIND_TABLE, TITLE_COL
from ..services.timeutil import now_iso
from ..services.workflow import PermissionDenied, WorkflowError
from ..vocab import KIND_LABELS, VISIBILITIES

bp = Blueprint("editor", __name__, url_prefix="/editor")

TABS = [("new", "New", ("submitted",)), ("review", "Under review", ("under_review",)),
        ("approved", "Approved, awaiting publication", ("approved",)),
        ("with_contributor", "Returned to contributor", ("needs_revision",)),
        ("decided", "Recently decided", ("published", "rejected"))]


def _flags(db, s):
    """Review aids shown in the queue. They inform; they never decide."""
    out = []
    d = json.loads(s["proposed_data"])
    data = d.get("changes", d)
    if s["kind"] == "person" and data.get("living_status") == "living":
        out.append("Living person: consent needed")
    if s["kind"] == "correction" and data.get("living_status") == "living":
        out.append("Marks person as living")
    if s["kind"] in ("person", "family", "place", "event") and not data.get("sources"):
        out.append("No sources")
    if s["kind"] == "person":
        names = [data.get("preferred_name"), data.get("full_name")] + data.get("aliases", [])
        if duplicates.find_person_candidates(db, names, limit=1):
            out.append("Possible duplicate")
    if s["kind"] == "correction" and s["base_revision"] is not None and \
            entities.latest_revision_number(db, s["target_entity_id"]) > s["base_revision"]:
        out.append("Record changed since submission")
    if s["rights_note"]:
        out.append("Rights/consent note")
    return out


@bp.route("")
@require("queue.view")
def queue():
    db = get_db()
    tab = request.args.get("tab", "new")
    statuses = dict((k, st) for k, _, st in TABS).get(tab)
    if not statuses:
        abort(404)
    kind = request.args.get("kind") or None
    if kind and kind not in KIND_LABELS:
        kind = None
    rows = workflow.queue(db, statuses, kind=kind, limit=200)
    if tab == "decided":
        rows = sorted(rows, key=lambda r: r["updated_at"], reverse=True)[:50]
    counts = {k: db.execute(f"SELECT COUNT(*) FROM submissions WHERE status IN ({','.join('?' * len(st))})", st).fetchone()[0]
              for k, _, st in TABS if k != "decided"}
    items = [{"s": s, "title": workflow.title_for(db, s), "flags": _flags(db, s)} for s in rows]
    new_msgs = db.execute("SELECT COUNT(*) FROM contact_messages WHERE status='new'").fetchone()[0]
    return render_template("editor/queue.html", items=items, tab=tab, tabs=TABS, counts=counts, kind=kind,
                           kinds=("person", "family", "place", "event", "source", "relationship", "correction"),
                           new_msgs=new_msgs)


def _staff_submission(sid):
    s = workflow.get_for_user(get_db(), g.user, sid)
    if not s:
        abort(404)
    return s


@bp.route("/submissions/<int:sid>")
@require("submission.review")
def review(sid):
    db = get_db()
    s = _staff_submission(sid)
    d = json.loads(s["proposed_data"])
    ctx = {"s": s, "title": workflow.title_for(db, s), "flags": _flags(db, s),
           "events": workflow.visible_events(db, g.user, sid, as_staff=True),
           "submitter": db.execute("SELECT username, display_name FROM users WHERE id=?", (s["submitter_id"],)).fetchone(),
           "is_own": s["submitter_id"] == g.user.id and not current_app.config["ALLOW_SELF_REVIEW"]}
    data = d
    if s["kind"] == "correction":
        target = entities.get(db, s["target_entity_id"])
        ctx["target"], ctx["target_title"] = target, entities.title_of(db, target["id"])
        ctx["diff"] = records.diff(db, target["kind"], target["id"], d["changes"])
        data = d["changes"]
    else:
        ctx["rows"] = records.display_rows(db, s["kind"], d)
    if s["kind"] == "person" or (s["kind"] == "correction" and ctx["target"]["kind"] == "person"):  # noqa: target set above for corrections
        names = [data.get("preferred_name"), data.get("full_name")] + data.get("aliases", [])
        by = (data.get("birth") or {}).get("start")
        ctx["candidates"] = duplicates.find_person_candidates(
            db, names, birth_year=by[:4] if by else None,
            exclude_entity_id=s["target_entity_id"])
    ctx["needs_consent"] = (s["kind"] == "person" and data.get("living_status") == "living")
    ctx["family"] = entities.get(db, s["family_scope_id"]) if s["family_scope_id"] else None
    ctx["sources"] = data.get("sources") or []
    return render_template("editor/review.html", **ctx)


@bp.route("/submissions/<int:sid>/transition", methods=["POST"])
@require("submission.review")
def transition(sid):
    db = get_db()
    _staff_submission(sid)
    to = request.form.get("to", "")
    try:
        workflow.transition(db, g.user, sid, to, message=request.form.get("message"),
                            internal_note=request.form.get("internal_note"),
                            consent_confirmed=request.form.get("consent_confirmed") == "1",
                            config=current_app.config)
        flash({"under_review": "Review started.", "needs_revision": "Returned to the contributor with your message.",
               "approved": "Approved. It is not public until you publish it.", "rejected": "Rejected. The contributor has been told why.",
               "published": "Published. The record is now part of the archive."}.get(to, "Updated."), "ok")
    except PermissionDenied as e:
        flash(str(e), "error")
    except WorkflowError as e:
        flash(str(e), "error")
    return redirect(url_for("editor.review", sid=sid))


@bp.route("/submissions/<int:sid>/note", methods=["POST"])
@require("confidential.view")
def note(sid):
    _staff_submission(sid)
    try:
        workflow.add_internal_note(get_db(), g.user, sid, request.form.get("internal_note"))
        flash("Internal note added. The contributor cannot see it.", "ok")
    except (PermissionDenied, WorkflowError) as e:
        flash(str(e), "error")
    return redirect(url_for("editor.review", sid=sid))


# ───────────── staff record management ─────────────
@bp.route("/records")
@require("record.view_any")
def records_list():
    db = get_db()
    kind = request.args.get("kind", "person")
    if kind not in ("person", "family", "place", "event", "source"):
        abort(404)
    vis = request.args.get("visibility") or None
    q = (request.args.get("q") or "").strip()[:100]
    sql = (f"SELECT e.*, t.{TITLE_COL[kind]} AS title FROM entities e JOIN {KIND_TABLE[kind]} t ON t.entity_id=e.id "
           f"WHERE e.kind=? AND e.deleted_at IS NULL")
    args = [kind]
    if vis in VISIBILITIES:
        sql, args = sql + " AND e.visibility=?", args + [vis]
    if q:
        sql, args = sql + f" AND (t.{TITLE_COL[kind]} LIKE ? OR e.public_id=?)", args + [f"%{q}%", q]
    rows = db.execute(sql + f" ORDER BY lower(t.{TITLE_COL[kind]}) LIMIT 500", args).fetchall()
    return render_template("editor/records.html", rows=rows, kind=kind, vis=vis, q=q)


def _staff_entity(public_id):
    e = entities.get_by_public_id(get_db(), public_id)
    if not e or e["kind"] not in ("person", "family", "place", "event", "source"):
        abort(404)
    return e


@bp.route("/records/<public_id>")
@require("record.view_any")
def record(public_id):
    db = get_db()
    e = _staff_entity(public_id)
    sub = entities.subtype_row(db, e["id"])
    revs = db.execute("SELECT r.revision_number, r.change_summary, r.reason, r.created_at, r.submission_id, u.username "
                      "FROM revisions r LEFT JOIN users u ON u.id=r.actor_id WHERE r.entity_id=? ORDER BY r.revision_number DESC",
                      (e["id"],)).fetchall()
    cites = db.execute("SELECT c.*, s.title FROM citations c JOIN sources s ON s.entity_id=c.source_id WHERE c.target_id=? ORDER BY c.id",
                       (e["id"],)).fetchall()
    names = db.execute("SELECT * FROM entity_names WHERE entity_id=? ORDER BY id", (e["id"],)).fetchall()
    reps = families.list_for_family(db, e["id"]) if e["kind"] == "family" else []
    fields = {k: sub[k] for k in sub.keys() if k not in ("entity_id", "kind") and sub[k] not in (None, "")}
    return render_template("editor/record.html", e=e, title=entities.title_of(db, e["id"]), fields=fields, revs=revs,
                           cites=cites, names=names, reps=reps, visibilities=VISIBILITIES,
                           living=(e["kind"] == "person" and sub["living_status"] == "living"))


@bp.route("/records/<public_id>/state", methods=["POST"])
@require("record.restrict")
def record_state(public_id):
    db = get_db()
    e = _staff_entity(public_id)
    vis = request.form.get("visibility")
    status = request.form.get("status") or None
    reason = (request.form.get("reason") or "").strip()[:1000]
    if vis not in VISIBILITIES or status not in (None, "published", "archived"):
        abort(400)
    if not reason:
        flash("Please record a reason. It is kept in the audit log.", "error")
        return redirect(url_for("editor.record", public_id=public_id))
    sub = entities.subtype_row(db, e["id"])
    if e["kind"] == "person" and sub["living_status"] == "living" and vis == "public" and request.form.get("consent_confirmed") != "1":
        flash("This person is recorded as living. Confirm that consent to publish has been obtained.", "error")
        return redirect(url_for("editor.record", public_id=public_id))
    with tx(db):
        entities.set_state(db, e["id"], status=status, visibility=vis, actor_id=g.user.id, reason=reason)
    flash("Record access updated.", "ok")
    return redirect(url_for("editor.record", public_id=public_id))


@bp.route("/records/<public_id>/slug", methods=["POST"])
@require("record.restrict")
def record_slug(public_id):
    db = get_db()
    e = _staff_entity(public_id)
    with tx(db):
        new = entities.change_slug(db, e["id"], request.form.get("slug", ""), g.user.id)
    flash(f"Address changed to “{new}”. The old address redirects here.", "ok")
    return redirect(url_for("editor.record", public_id=public_id))


@bp.route("/families/<public_id>/representatives", methods=["POST"])
@require("family_rep.manage")
def grant_rep(public_id):
    db = get_db()
    e = _staff_entity(public_id)
    if e["kind"] != "family":
        abort(404)
    try:
        with tx(db):
            families.grant(db, g.user.id, request.form.get("username", ""), e["id"],
                           suggest_edits=bool(request.form.get("can_suggest_edits")),
                           propose_tree=bool(request.form.get("can_propose_tree")),
                           submit_media=bool(request.form.get("can_submit_media")))
        flash("Representative added.", "ok")
    except ValueError as exc:
        flash(str(exc), "error")
    return redirect(url_for("editor.record", public_id=public_id))


@bp.route("/families/<public_id>/representatives/<int:gid>/revoke", methods=["POST"])
@require("family_rep.manage")
def revoke_rep(public_id, gid):
    db = get_db()
    e = _staff_entity(public_id)
    grant = db.execute("SELECT * FROM family_representatives WHERE id=? AND family_id=?", (gid, e["id"])).fetchone()
    if not grant:
        abort(404)
    with tx(db):
        families.revoke(db, g.user.id, gid)
    flash("Representative permission revoked.", "ok")
    return redirect(url_for("editor.record", public_id=public_id))


# ───────────── contact messages / public correction requests ─────────────
@bp.route("/messages")
@require("messages.view")
def messages():
    status = "handled" if request.args.get("status") == "handled" else "new"
    rows = get_db().execute("SELECT * FROM contact_messages WHERE status=? ORDER BY id DESC LIMIT 200", (status,)).fetchall()
    return render_template("editor/messages.html", rows=rows, status=status)


@bp.route("/messages/<int:mid>/handled", methods=["POST"])
@require("messages.view")
def message_handled(mid):
    db = get_db()
    with tx(db):
        db.execute("UPDATE contact_messages SET status='handled', handled_by=? WHERE id=?", (g.user.id, mid))
        audit.log(db, g.user.id, "contact.handled", "contact_message", mid)
    return redirect(url_for("editor.messages"))
