# Roles and permissions

Enforced on the server in `elf_archive/permissions.py` (role → permission matrix), in route guards (`security.require`), and again inside services (`services/workflow.py`). Hiding a button is never the protection. The matrix is verified by forged-request tests in `tests/test_http.py`.

Roles are additive. Every active account is a **contributor**. **Family representative** is not a role: it is a grant on one specific family, made and revoked by editors, with three separate switches.

## Matrix

| Capability | Visitor | Contributor | Family rep (own family only) | Moderator | Editor | Administrator |
| --- | :-: | :-: | :-: | :-: | :-: | :-: |
| Browse published public records, search, timeline | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Send a contact / correction message | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Save drafts (before email verification) | | ✓ | ✓ | ✓ | ✓ | ✓ |
| Submit records and corrections (verified email) | | ✓ | ✓ | ✓ | ✓ | ✓ |
| See own submissions and editors' messages to them | | ✓ | ✓ | ✓ | ✓ | ✓ |
| See editors' internal notes | | | | | ✓ | ✓ |
| Withdraw own pending submission | | ✓ | ✓ | ✓ | ✓ | ✓ |
| Propose relationships for a family | | | ✓ (if granted) | | ✓ | ✓ |
| Suggest edits to the family record | | ✓ (any public record) | ✓ | | ✓ | ✓ |
| Publish anything directly | | | ✗ | ✗ | via review only | via review only |
| View editorial queue, review, return, approve, reject, publish | | | | | ✓ | ✓ |
| Review own submission | | | | | ✗ (configurable) | ✗ (configurable) |
| See restricted / private / draft records | | | | | ✓ | ✓ |
| Restrict, unpublish, republish, change slug (reason required) | | | | | ✓ | ✓ |
| Grant / revoke family representatives | | | | | ✓ | ✓ |
| Read contact messages | | | | | ✓ | ✓ |
| Forum moderation (Milestone 5) | | | | ✓ | | |
| Manage users, roles, deactivate, anonymise | | | | | | ✓ |
| Audit log, categories, operational overview | | | | | | ✓ |
| Remove the last administrator | | | | | | ✗ (refused) |

Moderators have **no** access to archive submissions, restricted records or user management (spec §3.5). Editors cannot manage users or roles.

## Record-level rules

- A record is publicly visible only if it is published, public, not deleted and not merged. Anything else returns the same 404 as a record that never existed.
- People recorded as living are published as restricted unless an editor ticks the consent confirmation. A correction that marks a public person as living restricts the record automatically.
- Relationships to non-public people are omitted from every public page.
- Corrections can only target public records; the error for a private record is identical to the error for a nonexistent one.
- Contributors can only read, edit, submit or withdraw their own submissions (others' return 404).
- Every role change, account action, publication, correction, access change and family grant is written to the append-only audit log with actor, time and network address.
