"""Operator commands:  flask --app elf_archive <command>

  migrate            apply pending database migrations
  create-admin       create the first administrator (prompts for the password; never pass it as an argument)
  send-email         deliver queued email through SMTP (requires ELF_SMTP_* settings)
  reindex            rebuild the public search index from the database
  seed-test-data     DEVELOPMENT ONLY: add clearly labelled fictional records for trying the interface
"""
import getpass
import smtplib

import click
from flask import current_app
from werkzeug.security import generate_password_hash

from . import db as dbm
from .db import tx
from .services import accounts, audit, search
from .services.timeutil import now_iso


def _conn():
    return dbm.connect(current_app.config["DATABASE_PATH"])


def register(app):
    @app.cli.command("migrate")
    def migrate_cmd():
        conn = _conn()
        applied = dbm.migrate(conn)
        click.echo("Applied: " + (", ".join(applied) if applied else "nothing (already up to date)"))

    @app.cli.command("create-admin")
    @click.option("--email", required=True)
    @click.option("--username", required=True)
    @click.option("--display-name", default=None)
    def create_admin(email, username, display_name):
        conn = _conn()
        pw = getpass.getpass("Password (min 10 characters): ")
        if pw != getpass.getpass("Repeat password: "):
            raise click.ClickException("Passwords do not match.")
        err = accounts.validate_password(pw, email=email, username=username)
        if err:
            raise click.ClickException(err)
        with tx(conn):
            if conn.execute("SELECT 1 FROM users WHERE email=? OR username=?", (email, username)).fetchone():
                raise click.ClickException("A user with that email or username already exists.")
            cur = conn.execute("INSERT INTO users(email, username, display_name, password_hash, email_verified_at) VALUES (?,?,?,?,?)",
                               (email, username, display_name or username, generate_password_hash(pw), now_iso()))
            uid = cur.lastrowid
            for role in ("administrator", "editor"):
                conn.execute("INSERT INTO user_roles(user_id, role) VALUES (?,?)", (uid, role))
            audit.log(conn, None, "account.admin_created_cli", "user", uid)
        click.echo(f"Administrator '{username}' created.")

    @app.cli.command("send-email")
    def send_email():
        cfg = current_app.config
        if not cfg["SMTP_HOST"] or not cfg["SMTP_FROM"]:
            raise click.ClickException("Set ELF_SMTP_HOST and ELF_SMTP_FROM first. Queued mail stays in the outbox table.")

        def factory():
            s = smtplib.SMTP(cfg["SMTP_HOST"], cfg["SMTP_PORT"], timeout=20)
            s.starttls()
            if cfg["SMTP_USER"]:
                s.login(cfg["SMTP_USER"], cfg["SMTP_PASSWORD"])
            return s
        conn = _conn()
        click.echo(f"Sent {accounts.deliver_outbox(conn, factory, cfg['SMTP_FROM'])} message(s).")

    @app.cli.command("reindex")
    def reindex():
        conn = _conn()
        with tx(conn):
            search.rebuild_all(conn)
        click.echo("Search index rebuilt.")

    @app.cli.command("backup")
    @click.argument("destination")
    def backup(destination):
        """Consistent online copy of the database (safe while the site is running), then an integrity check."""
        import os
        import sqlite3
        if os.path.exists(destination):
            raise click.ClickException("Destination exists; choose a new file name (e.g. include the date).")
        src = _conn()
        dst = sqlite3.connect(destination)
        with dst:
            src.backup(dst)
        result = dst.execute("PRAGMA integrity_check").fetchone()[0]
        counts = {k: dst.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                  for k, t in (("entities", "entities"), ("revisions", "revisions"), ("users", "users"), ("audit", "audit_logs"))}
        dst.close()
        if result != "ok":
            raise click.ClickException(f"Backup written but integrity check failed: {result}")
        click.echo(f"Backup written to {destination} (integrity ok; {counts})")

    @app.cli.command("seed-test-data")
    def seed_test_data():
        if current_app.config["ENV"] == "production":
            raise click.ClickException("Refusing to add fictional data to a production database.")
        from .devseed import seed
        click.echo(seed(_conn()))
