"""DEVELOPMENT-ONLY fictional records for trying the interface.

Rules (spec §24.2): every record is flagged is_fictional_test=1 and visibly labelled on every page;
names end in "(FICTIONAL)"; no coordinates are given (we never invent geography, even for tests);
dated events use the year 2099 so nothing can be mistaken for history. Refuses to run in production
(see cli.py). Records still pass through the normal validation and publication code path."""
import json
import secrets

from .db import tx
from .services import entities, records
from .services.timeutil import now_iso
from werkzeug.security import generate_password_hash

DEV_USERS = [("dev_admin", ("administrator", "editor")), ("dev_editor", ("editor",)),
             ("dev_editor2", ("editor",)), ("dev_moderator", ("moderator",)), ("dev_contrib", ()), ("dev_rep", ())]

TAG = " (FICTIONAL)"


def seed(conn):
    if conn.execute("SELECT 1 FROM users WHERE username='dev_admin'").fetchone():
        return "Test data already present. Delete instance/archive.db to start over."
    password = "dev-" + secrets.token_urlsafe(9)
    with tx(conn):
        ids = {}
        for name, roles in DEV_USERS:
            cur = conn.execute("INSERT INTO users(email, username, display_name, password_hash, email_verified_at) VALUES (?,?,?,?,?)",
                               (f"{name}@example.test", name, name.replace("_", " ").title(), generate_password_hash(password), now_iso()))
            ids[name] = cur.lastrowid
            for r in roles:
                conn.execute("INSERT INTO user_roles(user_id, role) VALUES (?,?)", (cur.lastrowid, r))
        actor = ids["dev_editor"]

        def make(kind, raw):
            clean, errors = records.validate(conn, kind, raw)
            assert not errors, errors
            sid = conn.execute("INSERT INTO submissions(kind, proposed_data, status, submitter_id, submitted_at, published_at, reviewer_id) "
                               "VALUES (?,?, 'published', ?, ?, ?, ?)", (kind, json.dumps(clean), ids["dev_contrib"], now_iso(), now_iso(), actor)).lastrowid
            eid = records.apply_new(conn, kind, clean, actor_id=actor, submission_id=sid, fictional=True)
            conn.execute("UPDATE submissions SET result_entity_id=? WHERE id=?", (eid, sid))
            return entities.get(conn, eid)

        place = make("place", {"primary_name": "Testville" + TAG, "aliases": "Testvil\nTestvilla",
                               "place_type": "town_city",
                               "overview": "FICTIONAL test place for development. It has no coordinates on purpose."})
        fam = make("family", {"display_name": "Testfamily" + TAG, "region_note": "Testville (fictional)",
                              "summary": "FICTIONAL family record for development testing.",
                              "narrative": "This narrative is placeholder text for interface testing only.\nIt describes no real family."})
        a = make("person", {"preferred_name": "Testperson Alpha" + TAG, "aliases": "Testperson Alfa\nT. Alpha",
                            "living_status": "deceased", "birth": "c. 2099", "birth_place": place["public_id"],
                            "summary": "FICTIONAL person used to test profiles, aliases and uncertain dates.",
                            "sources": "Test Source Book (FICTIONAL) | p. 1 | https://example.test/book"})
        b = make("person", {"preferred_name": "Testperson Beta" + TAG, "living_status": "unknown", "birth": "2099",
                            "summary": "FICTIONAL person used to test relationships."})
        make("person", {"preferred_name": "Testperson Living" + TAG, "living_status": "living",
                        "summary": "FICTIONAL living person: must stay restricted and never appear publicly."})
        ev = make("event", {"title": "Test event: interface drill" + TAG, "event_type": "community_event",
                            "date": "2099-03 to 2099-05", "place": place["public_id"],
                            "summary": "FICTIONAL event used to test the timeline and date ranges."})
        make("event", {"title": "Test event with unknown date" + TAG, "event_type": "other",
                       "summary": "FICTIONAL event: its date is unknown and must be shown as unknown."})
        rel = records.validate(conn, "relationship", {"person_a": a["public_id"], "person_b": b["public_id"],
                                                      "relationship_type": "parent_of", "status": "uncertain",
                                                      "notes": "FICTIONAL relationship for testing."})[0]
        records.apply_relationship(conn, rel, actor_id=actor, submission_id=None)
        for p in (a, b):
            conn.execute("INSERT INTO family_memberships(family_id, person_id, publication_status, visibility, created_by) "
                         "VALUES (?,?, 'published', 'public', ?)", (fam["id"], p["id"], actor))
        conn.execute("INSERT INTO event_participants(event_id, person_id, role, evidence_status, publication_status) "
                     "VALUES (?,?, 'Participant (fictional)', 'unverified', 'published')", (ev["id"], a["id"]))
        conn.execute("INSERT INTO family_representatives(user_id, family_id, granted_by) VALUES (?,?,?)",
                     (ids["dev_rep"], fam["id"], ids["dev_admin"]))
    return ("Added fictional test records and dev accounts: " + ", ".join(n for n, _ in DEV_USERS) +
            f"\nPassword for all dev accounts: {password}\n(Development only. Do not reuse.)")
