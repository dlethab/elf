"""Browser end-to-end test (Playwright + Chromium) against a live server.

    python3 tests/e2e_browser.py [screenshot_dir]

Starts the app on a random local port with a throwaway database, then drives a real browser through
the core editorial workflow. Uses synthetic data labelled FICTIONAL only. Exits non-zero on failure."""
import os
import sys
import tempfile
import threading

from PIL import Image
from playwright.sync_api import expect, sync_playwright
from werkzeug.serving import make_server

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from elf_archive import create_app, db as dbm  # noqa: E402
from tests.helpers import PASSWORD, make_user, publish_new  # noqa: E402

SHOTS = sys.argv[1] if len(sys.argv) > 1 else None


def main():
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "e2e.db")
    conn = dbm.connect(path)
    dbm.migrate(conn)
    contrib = make_user(conn, "e2e_contrib")
    editor = make_user(conn, "e2e_editor", ["editor"])
    place = publish_new(conn, contrib, editor, "place", {"primary_name": "Testville (FICTIONAL)", "aliases": "Testvil"})
    conn.close()

    app = create_app({"ENV": "testing", "DATABASE_PATH": path, "SECRET_KEY": "e" * 40,
                      "MEDIA_ROOT": os.path.join(tmp, "media")})
    server = make_server("127.0.0.1", 0, app, threaded=True)
    base = f"http://127.0.0.1:{server.server_port}"
    threading.Thread(target=server.serve_forever, daemon=True).start()
    shot = (lambda page, name: page.screenshot(path=os.path.join(SHOTS, name), full_page=True)) if SHOTS else (lambda *a: None)
    steps = []

    with sync_playwright() as p:
        browser = p.chromium.launch()

        # 1. Contributor drafts, then submits a person record through the real form.
        ctx = browser.new_context(viewport={"width": 1280, "height": 900})
        page = ctx.new_page()
        page.goto(base + "/")
        shot(page, "01-home.png")
        page.get_by_role("link", name="Sign in", exact=True).click()
        page.fill("#f-identifier", "e2e_contrib")
        page.fill("#f-password", PASSWORD)
        page.click("button:has-text('Sign in')")
        expect(page.locator("h1")).to_contain_text("Welcome")
        page.get_by_role("link", name="New person", exact=True).click()
        page.fill("#f-preferred_name", "Testperson Browser (FICTIONAL)")
        page.fill("#f-aliases", "Testperson Brauser")
        page.fill("#f-birth", "c. 2099")
        page.fill("#f-birth_place", "Testville (FICTIONAL)")
        page.fill("#f-summary", "Synthetic person created by the browser test.")
        page.fill("#f-sources", "Test Register (FICTIONAL) | p. 9 | https://example.test/register")
        page.fill("#f-birth", "1952-02-30")                       # invalid on purpose: server must reject it
        page.click("button:has-text('Save draft')")
        expect(page.locator("#error-summary")).to_be_visible()
        expect(page.locator("#e-birth")).to_contain_text("does not exist")
        shot(page, "02-form-error.png")
        page.fill("#f-birth", "c. 2099")
        page.click("button:has-text('Save and submit for review')")
        expect(page.locator(".notice--ok")).to_contain_text("Submitted for editorial review")
        shot(page, "03-submitted.png")
        steps.append("contributor: invalid date rejected, draft saved and submitted")

        # 2. Not public yet.
        anon = browser.new_context().new_page()
        anon.goto(base + "/search?q=browser")
        expect(anon.locator("main")).to_contain_text("No published records match")
        steps.append("visitor: unpublished submission not searchable")

        # 3. Editor reviews, asks for changes.
        ectx = browser.new_context(viewport={"width": 1280, "height": 900})
        ed = ectx.new_page()
        ed.goto(base + "/auth/login")
        ed.fill("#f-identifier", "e2e_editor")
        ed.fill("#f-password", PASSWORD)
        ed.click("button:has-text('Sign in')")
        ed.goto(base + "/editor")
        shot(ed, "04-queue.png")
        ed.get_by_role("link", name="Testperson Browser (FICTIONAL)").click()
        ed.click("button:has-text('Start review')")
        ed.fill("#m-nr", "Please add an occupation if known (test).")
        ed.click("button:has-text('Return for revision')")
        expect(ed.locator(".notice--ok")).to_contain_text("Returned to the contributor")
        steps.append("editor: started review and returned it for revision")

        # 4. Contributor sees the request, revises, resubmits.
        page.goto(base + "/dashboard/submissions")
        page.get_by_role("link", name="Testperson Browser (FICTIONAL)").click()
        expect(page.locator("main")).to_contain_text("Please add an occupation")
        page.get_by_role("link", name="Edit", exact=True).click()
        expect(page.locator("#f-birth")).to_have_value("c. 2099")        # uncertainty survives the round trip
        page.fill("#f-occupation", "Test occupation (fictional)")
        page.click("button:has-text('Save and submit for review')")
        expect(page.locator(".notice--ok")).to_contain_text("Submitted")
        steps.append("contributor: saw the editor's message, revised and resubmitted")

        # 5. Editor approves and publishes.
        ed.reload()
        ed.click("button:has-text('Start review')")
        ed.click("button:has-text('Approve')")
        ed.on("dialog", lambda d: d.accept())
        shot(ed, "05-review-approved.png")
        ed.click("button:has-text('Publish')")
        expect(ed.locator(".notice--ok")).to_contain_text("Published")
        steps.append("editor: approved and published")

        # 6. Public: searchable by alias, profile shows uncertainty + citation, linked from the place page.
        anon.goto(base + "/search?q=brauser")
        anon.get_by_role("link", name="Testperson Browser (FICTIONAL)").click()
        expect(anon.locator("h1")).to_have_text("Testperson Browser (FICTIONAL)")
        expect(anon.locator("main")).to_contain_text("c. 2099")
        expect(anon.locator("main")).to_contain_text("Test Register (FICTIONAL)")
        expect(anon.locator(".notice--fictional")).to_have_count(0)       # real-flow record is not flagged as seed data
        shot(anon, "06-person.png")
        anon.get_by_role("link", name="Testville (FICTIONAL)").click()
        expect(anon.locator("main")).to_contain_text("Testperson Browser (FICTIONAL)")
        steps.append("visitor: found by alias, profile shows approximate date and citation, linked from place page")

        # 7. Mobile: compact menu works and nothing scrolls sideways.
        m = browser.new_context(viewport={"width": 375, "height": 740}, is_mobile=True, has_touch=True).new_page()
        m.goto(base + "/people")
        expect(m.locator("#nav-toggle")).to_be_visible()
        expect(m.locator("#nav-wrap")).to_be_hidden()
        m.click("#nav-toggle")
        expect(m.locator("#nav-wrap")).to_be_visible()
        expect(m.locator("#nav-toggle")).to_have_attribute("aria-expanded", "true")
        overflow = m.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 0, f"horizontal overflow of {overflow}px on mobile"
        shot(m, "07-mobile-menu.png")
        m.goto(base + "/map")
        expect(m.locator("main")).to_contain_text("Places without documented coordinates")
        steps.append("mobile: menu toggles, no horizontal overflow, map list alternative reachable")

        # 8. Keyboard: first Tab reaches the skip link and it moves focus to main.
        k = browser.new_context().new_page()
        k.goto(base + "/")
        k.keyboard.press("Tab")
        expect(k.locator(".skip")).to_be_focused()
        k.keyboard.press("Enter")
        assert k.evaluate("document.activeElement.id") == "main"
        steps.append("keyboard: skip link works")

        # 9. Languages: the switcher changes the interface; Arabic is right-to-left and fits a phone screen.
        lc = browser.new_context(viewport={"width": 1280, "height": 900})
        lp = lc.new_page()
        lp.goto(base + "/people")
        lp.get_by_role("link", name="العربية").click()
        expect(lp.locator("html")).to_have_attribute("dir", "rtl")
        expect(lp.locator("html")).to_have_attribute("lang", "ar")
        assert lp.url.endswith("/people"), lp.url                       # stayed on the same page
        expect(lp.locator("h1")).to_have_text("الأشخاص")
        expect(lp.locator(".lang-note")).to_be_visible()                 # draft-translation notice
        shot(lp, "09-arabic-people.png")
        lp.goto(base + "/")
        shot(lp, "09-arabic-home.png")
        lp.get_by_role("link", name="ትግርኛ").click()
        expect(lp.locator("html")).to_have_attribute("dir", "ltr")
        expect(lp.locator("#nav-wrap")).to_contain_text("ሰባት")
        shot(lp, "09-tigrinya-home.png")
        lm = browser.new_context(viewport={"width": 375, "height": 740}, is_mobile=True, has_touch=True).new_page()
        lm.goto(base + "/language/ar?next=/")
        lm.click("#nav-toggle")
        expect(lm.locator("#nav-wrap")).to_be_visible()
        overflow = lm.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 0, f"horizontal overflow of {overflow}px on mobile (Arabic)"
        shot(lm, "09-arabic-mobile.png")
        lp.get_by_role("link", name="English").click()
        expect(lp.locator("html")).to_have_attribute("lang", "en")
        steps.append("languages: switch to Arabic (RTL) and Tigrinya and back, no overflow on mobile in Arabic")

        # 10. Photos: contributor uploads through the real form (with progress), editor approves, visitors see it.
        img_path = os.path.join(tmp, "upload-test.jpg")
        Image.new("RGB", (1200, 800), (150, 110, 70)).save(img_path, "JPEG")
        page.goto(base + "/contribute/person")
        page.fill("#f-preferred_name", "Testperson Photo Browser (FICTIONAL)")
        page.click("button:has-text('Save draft')")
        expect(page.locator(".notice--ok")).to_contain_text("Draft saved")
        page.set_input_files("#f-photo", img_path)
        page.fill("#f-caption", "Synthetic colour block for the browser test (FICTIONAL)")
        page.select_option("#f-rights_status", "copyrighted_permission_granted")
        page.fill("#f-rights_holder", "Test Holder (FICTIONAL)")
        page.check("#f-rights_declared")
        page.click("button:has-text('Upload photo')")
        expect(page.locator(".notice--ok")).to_contain_text("Photo added")
        thumb = page.locator(".photo-list img").first
        expect(thumb).to_be_visible()
        assert thumb.evaluate("i => i.naturalWidth") > 0
        shot(page, "10-photo-uploaded.png")
        page.click("button:has-text('Submit for review')")
        expect(page.locator(".notice--ok")).to_contain_text("Submitted")
        ed.goto(base + "/editor")
        ed.get_by_role("link", name="Testperson Photo Browser (FICTIONAL)").click()
        expect(ed.locator("main")).to_contain_text("Photo decisions needed")
        ed.click("button:has-text('Start review')")
        ed.select_option("select[name=access]", "public")
        ed.select_option("select[name=rights_status]", "copyrighted_permission_granted")
        ed.click("button:has-text('Save photo decision')")
        expect(ed.locator(".notice--ok")).to_contain_text("Photo decision saved")
        shot(ed, "10-photo-review.png")
        ed.click("button:has-text('Approve')")
        ed.click("button:has-text('Publish')")
        expect(ed.locator(".notice--ok")).to_contain_text("Published")
        anon.goto(base + "/archive")
        anon.locator(".gallery a").first.click()
        img = anon.locator("figure.photo img")
        expect(img).to_be_visible()
        assert img.evaluate("i => i.naturalWidth") > 0
        expect(anon.locator("main")).to_contain_text("Testperson Photo Browser (FICTIONAL)")
        shot(anon, "10-archive-item.png")
        steps.append("photos: uploaded with progress, decided and published by an editor, visible to visitors")

        browser.close()
    server.shutdown()
    for s in steps:
        print("PASS", s)
    print(f"{len(steps)} browser scenarios passed")


if __name__ == "__main__":
    main()
