"""Photographs attached to contributions.

Lifecycle:
  1. A contributor uploads a photo to their own DRAFT (or returned) submission, with a caption,
     photographer, date and an honest statement of its rights. Nothing is public.
  2. While reviewing, an editor decides per photo: include or leave out, public or restricted, and
     the rights status they have established. A photo can only be public with rights that allow it.
  3. Publishing the submission turns each included photo into an archive item linked to the record.

File safety: the type is checked from the file's CONTENT (Pillow), never its name; size and pixel
count are limited; files are stored under random keys outside the web root. Visitors only ever get
re-encoded copies (display size and thumbnail) with all embedded metadata removed, including GPS
location. The untouched original is preserved for the archive and is visible to staff only.
"""
import hashlib
import io
import warnings

from PIL import Image, ImageOps, UnidentifiedImageError

from . import audit, dates, entities, ratelimit, search, storage as storage_mod
from .entities import PUBLIC_WHERE
from .timeutil import now_iso
from .workflow import EDITABLE, PHOTO_KINDS, PermissionDenied, WorkflowError
from ..db import tx
from ..vocab import CONTRIBUTOR_RIGHTS, PUBLIC_RIGHTS, RIGHTS_STATUSES

FORMATS = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}
DISPLAY_SIDE, THUMB_SIDE = 1600, 480
Image.MAX_IMAGE_PIXELS = 60_000_000          # larger images are refused (decompression-bomb guard)
REVIEW_STATES = ("submitted", "under_review", "approved")


class PhotoError(Exception):
    """Validation problems, as {field: message}. Messages are English msgids (translated in templates)."""

    def __init__(self, errors):
        super().__init__("; ".join(errors.values()))
        self.errors = errors


# ───────────── image handling ─────────────
def _identify(data):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(data)) as im:
                fmt = im.format
                im.verify()                   # structural check of the whole file
            im = Image.open(io.BytesIO(data))
            im.load()
    except (UnidentifiedImageError, Image.DecompressionBombError, Image.DecompressionBombWarning,
            OSError, SyntaxError, ValueError):
        raise PhotoError({"photo": "This file is not a photo the archive can accept. Use a JPEG, PNG or WebP image."})
    if fmt not in FORMATS:
        raise PhotoError({"photo": "This file is not a photo the archive can accept. Use a JPEG, PNG or WebP image."})
    return im, fmt


def _derive(im, side):
    """A re-encoded JPEG copy. Nothing embedded in the original (EXIF, GPS, comments) is carried over."""
    im = ImageOps.exif_transpose(im)             # keep the photo upright once orientation data is dropped
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        im = im.convert("RGBA")
        flat = Image.new("RGB", im.size, (255, 255, 255))
        flat.paste(im, mask=im.getchannel("A"))
        im = flat
    elif im.mode != "RGB":
        im = im.convert("RGB")
    im.thumbnail((side, side), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=85, optimize=True, progressive=True)
    return buf.getvalue(), im.size


# ───────────── metadata ─────────────
def validate_meta(form):
    def text(name, limit):
        v = " ".join((form.get(name) or "").split())
        if len(v) > limit:
            errors[name] = "This is too long."
        return v or None

    errors = {}
    clean = {"caption": text("caption", 500), "creator_text": text("creator_text", 200),
             "place_note": text("place_note", 1000), "people_note": text("people_note", 1000),
             "rights_holder": text("rights_holder", 300)}
    if not clean["caption"]:
        errors["caption"] = "Describe what the photo shows."
    try:
        clean["taken"] = dates.parse(form.get("taken") or "")
    except dates.DateError:
        errors["taken"] = "Use a form like 1952, 1952-03, 1952-03-14, c. 1952, 1950s, or 1950 to 1955."
    rights = (form.get("rights_status") or "").strip()
    if rights not in CONTRIBUTOR_RIGHTS:
        errors["rights_status"] = "Choose one of the listed options."
    clean["rights_status"] = rights
    if form.get("rights_declared") != "1":
        errors["rights_declared"] = "Please confirm this statement to upload the photo."
    return clean, errors


# ───────────── contributor actions ─────────────
def _own_editable(db, user, sid):
    s = db.execute("SELECT * FROM submissions WHERE id=?", (sid,)).fetchone()
    if not s or s["submitter_id"] != user.id:
        raise PermissionDenied("Not your submission.")
    if s["status"] not in EDITABLE:
        raise WorkflowError("Photos can only be added or removed while the submission is a draft or has been returned to you.")
    if s["kind"] not in PHOTO_KINDS:
        raise WorkflowError("Photos cannot be attached to a relationship proposal.")
    return s


def add(db, store, user, sid, data, filename, form, *, config):
    """Validate and store one photo on the user's own editable submission. Returns its id."""
    if config.get("REQUIRE_EMAIL_VERIFICATION", True) and not user.email_verified:
        raise PermissionDenied("Please verify your email address before uploading photos.")
    _own_editable(db, user, sid)
    clean, errors = validate_meta(form)
    if not data:
        errors["photo"] = "Choose a photo to upload."
    elif len(data) > config["MAX_PHOTO_BYTES"]:
        errors["photo"] = "This photo is too large. Reduce its size and try again."
    if errors:
        raise PhotoError(errors)
    im, fmt = _identify(data)
    if count(db, sid) >= config["MAX_PHOTOS_PER_SUBMISSION"]:
        raise PhotoError({"photo": "This submission already has the maximum number of photos."})
    digest = hashlib.sha256(data).hexdigest()
    if db.execute("SELECT 1 FROM media_files WHERE submission_id=? AND file_role='original' AND sha256=?", (sid, digest)).fetchone():
        raise PhotoError({"photo": "This photo is already attached to this submission."})
    if not ratelimit.allow(db, f"upload:{user.id}", 60, 3600):
        raise PhotoError({"photo": "You have uploaded many photos recently. Please wait a while before adding more."})

    display, dsize = _derive(im, DISPLAY_SIDE)
    thumb, tsize = _derive(im, THUMB_SIDE)
    files = [(storage_mod.new_key(), data, FORMATS[fmt], im.size, "original"),
             (storage_mod.new_key(), display, "image/jpeg", dsize, "access_derivative"),
             (storage_mod.new_key(), thumb, "image/jpeg", tsize, "thumbnail")]
    written = []
    try:
        for key, blob, *_ in files:
            store.put(key, blob)
            written.append(key)
        with tx(db):
            orig_id = None
            for key, blob, mime, (w, h), role in files:
                cur = db.execute(
                    "INSERT INTO media_files(submission_id, storage_key, original_filename, mime_type, size_bytes, width, height, "
                    "sha256, file_role, derived_from_id, access_level, processing_status, uploaded_by) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?, 'private', 'done', ?)",
                    (sid, key, (filename or "")[:200] or None, mime, len(blob), w, h, hashlib.sha256(blob).hexdigest(),
                     role, orig_id, user.id))
                orig_id = orig_id or cur.lastrowid
            taken = clean["taken"]
            cur = db.execute(
                "INSERT INTO submission_photos(submission_id, original_media_id, caption, creator_text, taken_start, taken_end, "
                "taken_precision, taken_note, place_note, people_note, rights_holder, rights_status, rights_declared) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1)",
                (sid, orig_id, clean["caption"], clean["creator_text"], taken.start, taken.end, taken.precision, taken.note,
                 clean["place_note"], clean["people_note"], clean["rights_holder"], clean["rights_status"]))
            db.execute("UPDATE submissions SET updated_at=? WHERE id=?", (now_iso(), sid))
            audit.log(db, user.id, "photo.uploaded", "submission", sid, {"photo": cur.lastrowid, "sha256": digest})
            return cur.lastrowid
    except BaseException:
        for key in written:                  # never leave stored files without a database row
            store.delete(key)
        raise


def remove(db, store, user, sid, photo_id):
    """Contributors may remove their own photo before review. Not yet an archive record, so it is deleted."""
    with tx(db):
        _own_editable(db, user, sid)
        p = db.execute("SELECT * FROM submission_photos WHERE id=? AND submission_id=?", (photo_id, sid)).fetchone()
        if not p:
            raise WorkflowError("Photo not found.")
        keys = [r["storage_key"] for r in db.execute(
            "SELECT storage_key FROM media_files WHERE id=? OR derived_from_id=?", (p["original_media_id"],) * 2)]
        db.execute("DELETE FROM submission_photos WHERE id=?", (photo_id,))
        db.execute("DELETE FROM media_files WHERE derived_from_id=?", (p["original_media_id"],))
        db.execute("DELETE FROM media_files WHERE id=?", (p["original_media_id"],))
        audit.log(db, user.id, "photo.removed", "submission", sid, {"photo": photo_id})
    for k in keys:
        store.delete(k)


# ───────────── reading ─────────────
def count(db, sid):
    return db.execute("SELECT COUNT(*) FROM submission_photos WHERE submission_id=?", (sid,)).fetchone()[0]


def pending_count(db, sid):
    return db.execute("SELECT COUNT(*) FROM submission_photos WHERE submission_id=? AND editor_decision='pending'",
                      (sid,)).fetchone()[0]


def list_for_submission(db, sid):
    return db.execute(
        "SELECT p.*, o.storage_key AS original_key, o.original_filename, o.size_bytes, o.width, o.height, o.mime_type, o.sha256, "
        "(SELECT storage_key FROM media_files WHERE derived_from_id=o.id AND file_role='thumbnail') AS thumb_key, "
        "(SELECT storage_key FROM media_files WHERE derived_from_id=o.id AND file_role='access_derivative') AS display_key, "
        "e.public_id AS item_public_id, e.visibility AS item_visibility "
        "FROM submission_photos p JOIN media_files o ON o.id=p.original_media_id "
        "LEFT JOIN entities e ON e.id=p.result_item_id WHERE p.submission_id=? ORDER BY p.id", (sid,)).fetchall()


def can_view_media(db, user, m):
    """The single access rule for every stored file. Called on EVERY request for a file, so a copied
    or guessed URL is worth nothing without the right to see the file."""
    if user and user.can("record.view_any"):
        return True
    if m["owner_id"] is not None:
        if m["file_role"] == "original":          # originals (with their embedded metadata) are staff-only
            return False
        ph = ",".join("?" * len(PUBLIC_RIGHTS))
        r = db.execute(f"SELECT 1 FROM entities e JOIN archive_items a ON a.entity_id=e.id WHERE e.id=? AND {PUBLIC_WHERE} "
                       f"AND a.access_level='public' AND a.rights_status IN ({ph})", (m["owner_id"], *PUBLIC_RIGHTS)).fetchone()
        return r is not None
    s = db.execute("SELECT submitter_id FROM submissions WHERE id=?", (m["submission_id"],)).fetchone()
    return bool(user and s and s["submitter_id"] == user.id)


# ───────────── editor actions ─────────────
def decide(db, user, sid, photo_id, form, *, config):
    if not user.can("submission.review"):
        raise PermissionDenied("You do not have permission for this action.")
    with tx(db):
        s = db.execute("SELECT * FROM submissions WHERE id=?", (sid,)).fetchone()
        p = db.execute("SELECT * FROM submission_photos WHERE id=? AND submission_id=?", (photo_id, sid)).fetchone()
        if not s or not p:
            raise WorkflowError("Photo not found.")
        if s["status"] not in REVIEW_STATES:
            raise WorkflowError("Photo decisions can only be made while the submission is being reviewed.")
        if s["submitter_id"] == user.id and not config.get("ALLOW_SELF_REVIEW", False):
            raise PermissionDenied("You cannot review your own submission. Another editor must do this.")
        decision = form.get("decision")
        access = form.get("access") or "restricted"
        rights = form.get("rights_status") or p["rights_status"]
        if decision not in ("accept", "decline") or access not in ("public", "restricted") or rights not in RIGHTS_STATUSES:
            raise WorkflowError("Choose one of the listed options.")
        if decision == "decline":
            access = "restricted"
        if access == "public" and rights not in PUBLIC_RIGHTS:
            raise WorkflowError("A photo can be public only when its rights allow it: public domain, permission granted, or licensed for use.")
        caption = " ".join((form.get("published_caption") or "").split())[:500] or p["caption"]
        note = (form.get("editor_note") or "").strip()[:2000] or None
        db.execute("UPDATE submission_photos SET editor_decision=?, editor_access=?, editor_rights_status=?, published_caption=?, "
                   "editor_note=?, decided_by=? WHERE id=?", (decision, access, rights, caption, note, user.id, photo_id))
        audit.log(db, user.id, "photo.decided", "submission", sid,
                  {"photo": photo_id, "decision": decision, "access": access, "rights": rights})


def _title(caption):
    if len(caption) <= 120:
        return caption
    cut = caption[:120].rsplit(" ", 1)[0]
    return cut + "…"


def publish_for_submission(db, s, record_id, actor_id):
    """Inside the publication transaction: turn included photos into archive items linked to the record."""
    photos = db.execute("SELECT * FROM submission_photos WHERE submission_id=? ORDER BY id", (s["id"],)).fetchall()
    if not photos:
        return 0
    if any(p["editor_decision"] == "pending" for p in photos):
        raise WorkflowError("Decide on every photo (include it or leave it out) before publishing.")
    record = db.execute(f"SELECT e.* FROM entities e WHERE e.id=? AND {PUBLIC_WHERE}", (record_id,)).fetchone()
    raw = entities.get(db, record_id)
    added = 0
    for p in photos:
        if p["editor_decision"] != "accept":
            continue
        rights = p["editor_rights_status"] or p["rights_status"]
        # A photo of a restricted record (e.g. a living person without consent) is never public.
        public = p["editor_access"] == "public" and rights in PUBLIC_RIGHTS and record is not None
        vis = "public" if public else "restricted"
        caption = p["published_caption"] or p["caption"]
        title = _title(caption)
        eid, pid, _ = entities.create_entity(db, "archive_item", title, created_by=actor_id, status="published",
                                             visibility=vis, fictional=bool(raw["is_fictional_test"]))
        db.execute(
            "INSERT INTO archive_items(entity_id, title, item_type, description, created_start, created_end, created_precision, "
            "created_note, creator, uploaded_by, provenance, rights_holder, rights_status, access_level) "
            "VALUES (?,?, 'photograph', ?,?,?,?,?,?,?,?,?,?,?)",
            (eid, title, caption if caption != title else None, p["taken_start"], p["taken_end"], p["taken_precision"],
             p["taken_note"], p["creator_text"], s["submitter_id"], "Contributed to the archive and reviewed by an editor.",
             p["rights_holder"], rights, vis))
        entities.add_name(db, eid, title, "preferred")
        db.execute("INSERT INTO archive_item_subjects(item_id, subject_id) VALUES (?,?)", (eid, record_id))
        db.execute("UPDATE media_files SET owner_id=?, access_level=? WHERE id=? OR derived_from_id=?",
                   (eid, vis, p["original_media_id"], p["original_media_id"]))
        db.execute("UPDATE submission_photos SET result_item_id=? WHERE id=?", (eid, p["id"]))
        entities.add_revision(db, eid, actor_id, "Created from an approved contribution", submission_id=s["id"])
        audit.log(db, actor_id, "archive_item.published", "archive_item", pid, {"submission": s["id"], "visibility": vis})
        search.reindex(db, eid)
        added += 1
    if added:
        entities.add_revision(db, record_id, actor_id, f"{added} photograph{'s' if added != 1 else ''} added",
                              submission_id=s["id"])
    return added


def sync_item_access(db, item_id):
    """Keep an archive item's access level and its files in step with the item's publication state."""
    e = entities.get(db, item_id)
    public = e["publication_status"] == "published" and e["visibility"] == "public" and not e["deleted_at"]
    level = "public" if public else "restricted"
    db.execute("UPDATE archive_items SET access_level=? WHERE entity_id=?", (level, item_id))
    db.execute("UPDATE media_files SET access_level=? WHERE owner_id=?", (level, item_id))
