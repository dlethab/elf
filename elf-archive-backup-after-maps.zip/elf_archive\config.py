import os

DEV_SECRET = "dev-only-insecure-secret-change-me"


def _bool(name, default):
    v = os.environ.get(name)
    return default if v is None else v.strip().lower() in ("1", "true", "yes", "on")


def load_config(overrides=None):
    env = (overrides or {}).get("ENV") or os.environ.get("ELF_ENV", "development")
    cfg = {
        "ENV": env,
        "SECRET_KEY": os.environ.get("ELF_SECRET_KEY", DEV_SECRET),
        "DATABASE_PATH": os.environ.get("ELF_DATABASE_PATH", "instance/archive.db"),
        "BASE_URL": os.environ.get("ELF_BASE_URL", "http://localhost:5000").rstrip("/"),
        "SITE_NAME": os.environ.get("ELF_SITE_NAME", "ELF Digital Historical Archive"),
        "CONTACT_EMAIL": os.environ.get("ELF_CONTACT_EMAIL", ""),
        "REQUIRE_EMAIL_VERIFICATION": _bool("ELF_REQUIRE_EMAIL_VERIFICATION", True),
        "ALLOW_SELF_REVIEW": _bool("ELF_ALLOW_SELF_REVIEW", False),
        "SESSION_LIFETIME_SECONDS": int(os.environ.get("ELF_SESSION_LIFETIME_SECONDS", 7 * 24 * 3600)),
        "SMTP_HOST": os.environ.get("ELF_SMTP_HOST", ""),
        "SMTP_PORT": int(os.environ.get("ELF_SMTP_PORT", 587)),
        "SMTP_USER": os.environ.get("ELF_SMTP_USER", ""),
        "SMTP_PASSWORD": os.environ.get("ELF_SMTP_PASSWORD", ""),
        "SMTP_FROM": os.environ.get("ELF_SMTP_FROM", ""),
        "AUTO_MIGRATE": _bool("ELF_AUTO_MIGRATE", False),
        # Uploaded files live OUTSIDE the web-served static folder and are only served through the
        # access-checking /media route. Local disk for now; S3-compatible storage is a later option.
        "MEDIA_ROOT": os.environ.get("ELF_MEDIA_ROOT", "instance/media"),
        # Optional street-level map layer (e.g. OpenStreetMap). Empty = the archive's own base map only,
        # with no third party involved. Example: https://tile.openstreetmap.org/{z}/{x}/{y}.png
        "MAP_TILE_URL": os.environ.get("ELF_MAP_TILE_URL", ""),
        "MAP_TILE_ATTRIBUTION": os.environ.get("ELF_MAP_TILE_ATTRIBUTION", ""),
        "MAX_PHOTO_BYTES": int(os.environ.get("ELF_MAX_PHOTO_MB", 15)) * 1024 * 1024,
        "MAX_PHOTOS_PER_SUBMISSION": int(os.environ.get("ELF_MAX_PHOTOS_PER_SUBMISSION", 10)),
        "MAX_CONTENT_LENGTH": (int(os.environ.get("ELF_MAX_PHOTO_MB", 15)) + 2) * 1024 * 1024,
    }
    cfg.update(overrides or {})
    if cfg["ENV"] == "production":
        if cfg["SECRET_KEY"] == DEV_SECRET or len(cfg["SECRET_KEY"]) < 32:
            raise RuntimeError("ELF_SECRET_KEY must be set to a random value of at least 32 characters in production.")
        if not cfg["BASE_URL"].startswith("https://"):
            raise RuntimeError("ELF_BASE_URL must be an https:// URL in production.")
    return cfg
