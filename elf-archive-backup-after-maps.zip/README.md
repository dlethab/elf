# ELF Digital Historical Archive

A connected, searchable historical archive for the Eritrean Liberation Front and Eritrea's independence struggle: people, families, places, events and sources as shared canonical records, with an editorial review workflow, claim-level citations and honest handling of uncertainty.

The authoritative product specification is `docs/SPECIFICATION.md`. Architecture, schema and route inventory are in `docs/ARCHITECTURE.md`; roles and permissions in `docs/PERMISSIONS.md`; what works and what does not yet in `docs/STATUS.md`.

## Requirements

- Python 3.12 or newer (SQLite with FTS5 is included with standard Python builds)
- Nothing else for development. No database server, no Node toolchain.

## Development setup

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env            # optional; defaults work for development

flask --app elf_archive migrate
flask --app elf_archive create-admin --email you@example.org --username you   # prompts for a password
flask --app elf_archive run --debug
```

Open http://localhost:5000. Mail you trigger (verification, password reset) is queued in the database; in development read it at http://localhost:5000/dev/outbox.

### Trying it with fictional data (development only)

```bash
flask --app elf_archive seed-test-data
```

This adds records named "… (FICTIONAL)", flagged in the database and labelled on every page, plus dev accounts (`dev_admin`, `dev_editor`, `dev_editor2`, `dev_moderator`, `dev_contrib`, `dev_rep`) with a printed random password. Fictional records carry no coordinates and use the year 2099 so they cannot be mistaken for history. The command refuses to run in production. Delete `instance/archive.db` to start over.

## Tests

```bash
python3 -m unittest discover -s tests -t .      # 59 unit + HTTP integration tests
python3 tests/e2e_browser.py [screenshot_dir]   # real-browser end-to-end run (needs Playwright Chromium)
```

## Operator commands

| Command | Purpose |
| --- | --- |
| `flask --app elf_archive migrate` | Apply pending database migrations (safe to re-run) |
| `flask --app elf_archive create-admin --email … --username …` | Create an administrator; the password is prompted, never passed on the command line |
| `flask --app elf_archive send-email` | Deliver queued email via SMTP (needs `ELF_SMTP_*`) |
| `flask --app elf_archive reindex` | Rebuild the public search index |
| `flask --app elf_archive seed-test-data` | Development only: fictional records and dev accounts |

## Production (summary)

1. Set `ELF_ENV=production`, a random `ELF_SECRET_KEY` (32+ characters) and an `https://` `ELF_BASE_URL`. The app refuses to start otherwise.
2. `pip install -r requirements.txt gunicorn`, then `flask --app elf_archive migrate` and `create-admin`.
3. Run `gunicorn --workers 3 --bind 127.0.0.1:8000 wsgi:app` behind a TLS-terminating reverse proxy (nginx or Caddy) that serves `elf_archive/static/` directly.
4. Schedule `flask --app elf_archive send-email` every few minutes once SMTP is configured.
5. Set up backups as described in `docs/OPERATIONS.md` before entering real records.

## Project layout

```
elf_archive/
  vocab.py            controlled vocabularies (single source for DB CHECK constraints and code)
  permissions.py      the permission matrix; every server-side check uses it
  migrations/         numbered SQL migrations
  db.py               connections, transactions, migration runner
  services/           business logic: accounts, entities, records, workflow, search, families, dates, names
  queries.py          read-side queries for public pages (always filtered to public records)
  security.py         CSRF, headers, cache policy, route guards
  web/                Flask blueprints: public, auth, dashboard, editor, admin
  templates/          Jinja templates; _macros.html holds the shared components
  static/             design-system CSS and progressive-enhancement JS
tests/                unit, HTTP integration and browser end-to-end tests
docs/                 specification, architecture, permissions, status, operations
```
