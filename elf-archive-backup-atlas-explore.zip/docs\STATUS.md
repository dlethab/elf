# Status (2026-10-14)

All six planned milestones are built. The software is ready to install on a server and use. Before launch, steps that need people outside the project remain: hosting, email, legal review, translation review, and independent accessibility and security reviews. They are listed in `LAUNCH_CHECKLIST.md`.

## Historical atlas upgrade (2026-10-14)

- **Map:** now a tilted 3D relief map of Eritrea (MapLibre GL JS with self-hosted elevation tiles from SRTM, GMTED2010 and ETOPO1, plus hillshading), replacing the flat Leaflet map.
  - Place markers are keyboard-reachable buttons, with distinct shapes for exact, approximate and region-only locations.
  - A side panel shows each place and its events, with their uncertainty.
  - There are controls for 2D/3D, facing north, resetting the view and map layers.
  - A period ribbon (events per year, split into exact, range and approximate) filters the map.
  - Each place has a shareable address (`/map?place=…`).
  - Without WebGL, visitors get the full list of places.
- **Timeline:** a time ruler (events per year by date certainty), decade sections, uncertainty marks on every event, and each event's places with links to them on the map.
- **Design:** both pages use a new dark "atlas" design system (`static/css/atlas.css`). Nothing is contacted outside this server.
- **3D atlas, second pass:**
  - Search across places (including other and historical names), people, events, organizations and archive records, with each result's record type shown.
  - Record previews list a record's places, so you choose which one to go to.
  - Place previews load on demand: summary, other names, events, people, organizations, photographs, and the sources for the location.
  - Marker shapes show the kind of place; the outline shows how precisely its location is known.
  - Filters for period, event type, place category, person, organization and archive materials, with removable chips.
  - Closing a preview restores the previous view.
  - On phones, previews open as a bottom sheet.
  - Full-screen mode, and touch gestures that only pan and zoom.
  - Timeline links open the event and its place and keep the period.
  - Fallbacks without WebGL, or when elevation data is missing.
- **Tested:** 192 unit tests and 14 browser scenarios. The atlas scenario covers search, previews, chips, the timeline link, the phone bottom sheet, the no-WebGL fallback and missing elevation data. axe-core passes on 36 pages.
- **Not yet:** historical routes and boundaries, which would need documented sources, and a per-place uncertainty radius (the data model records precision, not a radius). Map labels for modern towns and regions are in English only.

## One explore page: map and timeline together (2026-10-14)

- **One page, three addresses:** `/explore`, `/map` and `/timeline` all serve one page, starting in map, timeline or combined ("Map and timeline") mode; the combined mode is desktop only. Switching mode never reloads the page.
- **One shared state** (`static/js/atlas-state.js`) holds the mode, the filters (search, type, period, region, places of a kind, events at a place, person, organization, media) and the selection (place, event or other record).
  - The filter bar, chips, map, timeline and address all read it, so they cannot disagree.
  - Deliberate steps add a browser history entry, so back and forward work; typing and dragging only replace the current entry, and camera movement is never written.
- **Integration:**
  - A place's "Explore this place on the timeline" filters to events explicitly documented at that place, keeping the period and showing a removable chip and a context box.
  - An event's "Show on the map" centres on its single documented place or lets the visitor choose; with no documented place, nothing is drawn and the reason is given.
  - A period change applies to both views; a selection that no longer matches is closed with an explanation.
- **Shareable links are checked on the server:** only public records enter the page's state; anything else is dropped with a neutral notice that does not reveal whether the record exists. Older `/timeline?place=` links still work, read as "events at this place".
- **Tested:** 198 unit tests and 14 browser scenarios. The explore scenario covers all ten integration checks, including back and forward, a shared link, the phone layout and private records. axe-core passes on 38 pages.

## Interactive timeline (2026-10-14)

- **Horizontal timeline** (`/timeline`):
  - Zoom with buttons, Ctrl or pinch on the wheel, or + and −; move by dragging, horizontal scrolling or the earlier and later buttons.
  - An overview strip shows the whole filtered period with a window for what is in view.
  - "Use this view as the period" turns the visible years into the period filter.
  - Markers stack in rows; when there are too many to separate, they combine into "+n" buttons that zoom in.
- **Honest dates:** each event covers exactly the span its record allows (`atlas.date_interval`).
  - A day is a point. A month, year, decade or range is a bar meaning "somewhere within".
  - Approximate and decade-only dates are dashed. Undated events are listed but never placed.
  - Editors can mark a differing account as being about the date (migration 0010). The timeline, list and event page then say that sources disagree.
- **Markers:** shape shows the event category (armed conflict, political and organizational, lives and displacement, community and other), with colour repeating it.
- **Preview card:** category, date with its precision, any date disagreement, summary, an archival image, places (with location precision and map links), people and organizations. It sits beside the timeline on desktop and below it on phones.
- **Filters:** search, event type, period, region, place, person, organization, and "has photographs, documents or oral histories". All values come from the database, show as removable chips, and update the timeline, count, overview and list. The server-rendered list applies the same rules without JavaScript.
- **Linked to the map** (`static/js/atlas-state.js`), with the same address parameters and event rules on both pages:
  - "Show on the map" opens the event with its place and keeps the period and compatible filters.
  - On the map, "Events at this place on the timeline" opens the timeline focused on that place, keeping the period, with a "Back to this place on the map" link.
- **Event page:** date precision and disagreements; places with location precision and map links; oral histories; related events (same place or participant, with the reason given); links to the timeline and map.
- **Accessibility:** markers are buttons in date order with full descriptions; arrow keys move between events. The chronological list remains the alternative.
- **Tested:** 198 unit tests and 15 browser scenarios, including the full timeline-to-map workflow and the phone layout. axe-core passes on 37 pages.

## What works

**Records and connections**
- People, families, places, events, organizations and sources as shared records with permanent IDs and stable addresses (old addresses redirect).
- Names and aliases in any script, uncertain dates (approximate, decade, range, unknown), claim-level citations with evidence levels, differing accounts kept side by side.
- Links between records through the workflow: relationships, family memberships, affiliations with organizations (with role, dates, place and evidence), event participants.
- Complete revision history and an append-only audit log.

**Contributing and editing**
- Draft → submit → review → return for revision → approve → publish, plus reject and withdraw.
- Corrections to any public record, with a side-by-side diff for the editor.
- Editors can: edit directly with a reason; manage citations, differing accounts and links; merge duplicates (impact preview, permanent redirect); import CSV files (preview first, then submissions, then bulk publish); use a data-quality report; manage collections.
- Living people are protected by default. Family representatives have scoped, revocable grants.

**Files and oral histories**
- Contributors can upload photographs, PDF documents, audio and video. The type is checked from the file content, and PDFs with scripts or embedded files are refused.
- Images are re-encoded for visitors with all metadata (including GPS) removed. Audio and video metadata are stripped too when ffmpeg is installed.
- Originals are kept for staff. Every file request is checked against the item's access and rights, so a guessed address returns 404.
- Oral histories record consent per use and support embargoes, transcript and translation labelling, and timestamped transcripts that seek the recording. There is also a request-an-interview form.
- Researchers (granted by administrators) can see restricted items with research consent, and every such view is logged.

**Exploring**
- Global search across names, aliases, transliterations and permitted transcripts.
- A timeline with filters, and an interactive map on the archive's own base map of Eritrea (no third-party tile service). Places without coordinates are listed, never guessed.
- Family trees and connection diagrams, each with a list alternative.

**Community**
- Forum with categories, topics, replies, editing within a window (earlier versions kept), search and member profiles.
- Reports by category; moderation with logged reasons; posting pauses; reply notifications. Posting needs a verified email address.

**Accounts and security**
- Registration with email verification; lockout after repeated failures; password reset without revealing which accounts exist.
- Optional two-step sign-in (authenticator app, recovery codes, admin reset), which can be required for all staff.
- Server-side permission checks everywhere, CSRF protection, a strict Content-Security-Policy, HSTS in production, and correct visitor addresses behind a reverse proxy.

**Languages**
- English, Tigrinya and Arabic interfaces (Arabic right to left), switchable on every page.
- All public pages, contributor pages and information pages are translated.
- Staff tools and the draft legal pages are English only, and say so.

**Administration and operations**
- Operational overview: editorial backlog, data quality, media, rights and consent issues, forum reports, staff without two-step sign-in, last backup and export.
- User and role management, audit log, categories.
- Public data export (JSON + CSV, public fields only, audited) from the admin area or the command line.
- Backups of the database plus incremental media copies, recorded in the audit log.
- Email retried after temporary failures.

## What was tested

| Check | Result |
| --- | --- |
| `python -m unittest discover -s tests -t .` | **182 tests pass.** Covers services, schema rules, the workflow, forged requests across role boundaries, leak checks on every public surface (pages, search, sitemap, typeahead, map data, media, export), CSRF, sessions, lockout, two-step sign-in (including the RFC 6238 test vectors, replay and recovery codes), translations completeness, production settings, the reverse-proxy setting, email retries and the development seed |
| `python tests/e2e_browser.py` (Chromium) | **14 scenarios pass:** full editorial cycle, alias search, mobile menu, keyboard skip link, Arabic and Tigrinya (including Arabic on a 375 px phone), photo upload to publication, map with no third-party requests, forum report and moderation, duplicate merge with redirect, and an axe-core accessibility scan |
| Accessibility (axe-core 4.10.2, WCAG 2.0–2.2 A/AA rules) | **No violations on 35 pages:** public, signed-in and staff pages, in English, Arabic and dark mode. The scan found two problems, now fixed: map checkboxes below the 24 px target size, and dimmed text below AA contrast |
| `pip-audit` | No known vulnerabilities in the declared requirements or the installed environment (after upgrading pip) |
| Backup, then restore | Backup with integrity check and media copy run against the local database; the copy was restored, migrated forward and served pages and search correctly |
| Spec §26.3 scenarios | All 16 are covered by automated tests. For scenario 15, the mobile run opens the map and its list alternative, but touch gestures on the map itself are not automated |

**Not tested here:**
- ffmpeg is not installed on this machine, so stripping metadata from audio and video has not been run (its fallback has).
- Email has been tested with a simulated mail server, not a real provider.
- No load testing.
- The deployment guide has not been run on a real server from this machine.
- No independent accessibility audit or penetration test.

## What remains

**Needs people or accounts outside the project** (`LAUNCH_CHECKLIST.md`):
- A server, domain, SMTP account and off-site backup storage.
- Legal review of the privacy, terms, copyright and data pages, and a choice of data licence.
- Native-speaker review of the Tigrinya and Arabic translations. Both were written by an AI assistant without native-speaker review, and the site says they are drafts; marking a catalogue as reviewed removes the notice.
- An independent accessibility review with disabled users, and an independent security review.

**Known limits of the software:**
- SQLite on one server. It suits the expected scale; a PostgreSQL path is described in `ARCHITECTURE.md`.
- Media on local disk only (no S3-compatible storage yet).
- No built-in virus scanner (a scheduled ClamAV scan is described in `DEPLOYMENT.md`).
- No HEIC images (phones usually convert them when uploading through a browser).
- No captions for video.
- Files from rejected or withdrawn submissions are kept, and there is no clean-up command yet.
- Gregorian dates only (no Ethiopian calendar display).
- Staff tools are English only.
- The map shows modern borders and regions only; historical boundaries would need a sourced, licensed dataset.

## Configuration summary

Every setting is in `.env.example`. These must be set for production:
- `ELF_ENV=production`, `ELF_SECRET_KEY`, `ELF_BASE_URL` (https)
- `ELF_DATABASE_PATH`, `ELF_MEDIA_ROOT`
- `ELF_TRUSTED_PROXIES=1`
- `ELF_SMTP_*`, `ELF_CONTACT_EMAIL`

Recommended once staff are set up: `ELF_REQUIRE_STAFF_MFA=true`.
